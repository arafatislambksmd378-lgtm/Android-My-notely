package com.notegenie.app.plugins

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.provider.OpenableColumns
import android.os.ParcelFileDescriptor
import androidx.activity.result.ActivityResult
import androidx.core.app.ActivityCompat
import com.getcapacitor.*
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import com.notegenie.app.llm.LlamaRuntime
import com.rmtheis.tess_two.TessBaseAPI
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors

@CapacitorPlugin(name = "NoteGenieNative", permissions = [Permission(strings=[Manifest.permission.RECORD_AUDIO], alias="microphone")])
class NoteGenieNativePlugin : Plugin(), TextToSpeech.OnInitListener {
  private val io = Executors.newSingleThreadExecutor()
  private var speechModel: Model? = null
  private var speechService: SpeechService? = null
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var speechResult = ""
  private var loadedModelPath: String? = null

  override fun load() { tts = TextToSpeech(context, this); io.execute { copyAssetTree("tessdata", File(context.filesDir, "tessdata")); copyAssetTree("vosk-model-bn", File(context.filesDir, "vosk-model-bn")) } }
  private fun copyAssetTree(assetPath: String, target: File) {
    try {
      val children = context.assets.list(assetPath) ?: return
      if (children.isEmpty()) { target.parentFile?.mkdirs(); context.assets.open(assetPath).use { input -> target.outputStream().use { input.copyTo(it) } }; return }
      target.mkdirs()
      for (child in children) copyAssetTree("$assetPath/$child", File(target, child))
    } catch (_: Exception) { /* optional model assets are installed separately */ }
  }
  override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale("bn", "BD") }

  private fun db() = context.openOrCreateDatabase("notegenie.db", 0, null).apply {
    execSQL("CREATE TABLE IF NOT EXISTS notebooks(id TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL, closed INTEGER NOT NULL)")
    execSQL("CREATE TABLE IF NOT EXISTS notes(id TEXT PRIMARY KEY, notebook_id TEXT NOT NULL, title TEXT NOT NULL, html TEXT NOT NULL, tint TEXT NOT NULL, updated_at INTEGER NOT NULL)")
    execSQL("CREATE INDEX IF NOT EXISTS idx_notes_notebook ON notes(notebook_id)")
    execSQL("CREATE TABLE IF NOT EXISTS models(id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
    execSQL("CREATE TABLE IF NOT EXISTS chat_messages(id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
    execSQL("CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
  }
  @PluginMethod fun loadSnapshot(call: PluginCall) {
    io.execute { try {
      val d=db(); val root=org.json.JSONObject()
      val notebooks=org.json.JSONArray(); d.rawQuery("SELECT id,name,color,closed FROM notebooks",null).use { c -> while(c.moveToNext()) notebooks.put(org.json.JSONObject().put("id",c.getString(0)).put("name",c.getString(1)).put("color",c.getString(2)).put("closed",c.getInt(3)==1)) }
      val notes=org.json.JSONArray(); d.rawQuery("SELECT id,notebook_id,title,html,tint,updated_at FROM notes ORDER BY updated_at DESC",null).use { c -> while(c.moveToNext()) notes.put(org.json.JSONObject().put("id",c.getString(0)).put("notebookId",c.getString(1)).put("title",c.getString(2)).put("html",c.getString(3)).put("tint",c.getString(4)).put("updatedAt",c.getLong(5))) }
      val models=org.json.JSONArray(); d.rawQuery("SELECT payload FROM models",null).use { c -> while(c.moveToNext()) models.put(org.json.JSONObject(c.getString(0))) }
      val chat=org.json.JSONArray(); d.rawQuery("SELECT payload FROM chat_messages ORDER BY rowid",null).use { c -> while(c.moveToNext()) chat.put(org.json.JSONObject(c.getString(0))) }
      val meta=org.json.JSONObject(); d.rawQuery("SELECT key,value FROM app_meta",null).use { c -> while(c.moveToNext()) meta.put(c.getString(0),c.getString(1)) }
      d.close()
      if(notebooks.length()==0 && notes.length()==0) { call.resolve(JSObject().put("json",null)); return@execute }
      val profile=try{org.json.JSONObject(meta.optString("profile","{}"))}catch(_:Exception){org.json.JSONObject()}
      val settings=try{org.json.JSONObject(meta.optString("settings","{}"))}catch(_:Exception){org.json.JSONObject()}
      root.put("profile",profile).put("settings",settings).put("notebooks",notebooks).put("notes",notes).put("models",models).put("chat",chat).put("activeModelId",meta.optString("activeModelId",""))
      call.resolve(JSObject().put("json",root.toString()))
    } catch(e:Exception){call.reject("SQLite read failed: ${e.message}")} }
  }
  @PluginMethod fun saveSnapshot(call: PluginCall) {
    val json = call.getString("json") ?: run { call.reject("json required"); return }
    io.execute {
      val d=db(); d.beginTransaction()
      try {
        val root=org.json.JSONObject(json)
        listOf("notebooks","notes","models","chat_messages","app_meta").forEach { d.delete(it,null,null) }
        val nbs=root.optJSONArray("notebooks")?:org.json.JSONArray()
        for(i in 0 until nbs.length()){val o=nbs.getJSONObject(i);d.execSQL("INSERT OR REPLACE INTO notebooks VALUES(?,?,?,?)",arrayOf(o.optString("id"),o.optString("name"),o.optString("color"),if(o.optBoolean("closed"))1 else 0))}
        val notes=root.optJSONArray("notes")?:org.json.JSONArray()
        for(i in 0 until notes.length()){val o=notes.getJSONObject(i);d.execSQL("INSERT OR REPLACE INTO notes VALUES(?,?,?,?,?,?)",arrayOf(o.optString("id"),o.optString("notebookId"),o.optString("title"),o.optString("html"),o.optString("tint"),o.optLong("updatedAt")))}
        val models=root.optJSONArray("models")?:org.json.JSONArray()
        for(i in 0 until models.length()){val o=models.getJSONObject(i);d.execSQL("INSERT OR REPLACE INTO models VALUES(?,?)",arrayOf(o.optString("id"),o.toString()))}
        val chat=root.optJSONArray("chat")?:org.json.JSONArray()
        for(i in 0 until chat.length()){val o=chat.getJSONObject(i);d.execSQL("INSERT OR REPLACE INTO chat_messages VALUES(?,?)",arrayOf(o.optString("id"),o.toString()))}
        d.execSQL("INSERT OR REPLACE INTO app_meta VALUES('profile',?)",arrayOf((root.optJSONObject("profile")?:org.json.JSONObject()).toString()))
        d.execSQL("INSERT OR REPLACE INTO app_meta VALUES('settings',?)",arrayOf((root.optJSONObject("settings")?:org.json.JSONObject()).toString()))
        d.execSQL("INSERT OR REPLACE INTO app_meta VALUES('activeModelId',?)",arrayOf(root.optString("activeModelId","")))
        d.setTransactionSuccessful()
      } catch(e:Exception){call.reject("SQLite write failed: ${e.message}");return@execute}
      finally { d.endTransaction(); d.close() }
      call.resolve()
    }
  }

  @PluginMethod fun importModel(call: PluginCall) {
    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/octet-stream"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-gguf")) }
    startActivityForResult(call, intent, "modelPicked")
  }
  @ActivityCallback private fun modelPicked(call: PluginCall, result: ActivityResult) {
    if (result.resultCode != android.app.Activity.RESULT_OK) { call.reject("Model import cancelled"); return }
    val uri = result.data?.data ?: run { call.reject("No model selected"); return }
    io.execute { try {
      val name = queryName(uri); val target = File(context.filesDir, "models/$name"); target.parentFile?.mkdirs()
      val statSize = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if(c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L } ?: -1L
      if (statSize > 0 && context.filesDir.usableSpace < statSize + 64L * 1024 * 1024) { call.reject("Not enough free storage for this GGUF model"); return@execute }
      context.contentResolver.openInputStream(uri)!!.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
      val magic = ByteArray(4); target.inputStream().use { if(it.read(magic) != 4) throw Exception("File too small") }
      if (!name.endsWith(".gguf", true) || target.length() < 1024 * 1024 || String(magic, Charsets.US_ASCII) != "GGUF") { target.delete(); call.reject("Invalid GGUF file (GGUF magic header not found)"); return@execute }
      call.resolve(JSObject().put("path", target.absolutePath).put("name", name).put("size", target.length()))
    } catch (e: Exception) { call.reject("Import failed: ${e.message}") } }
  }
  private fun queryName(uri: Uri): String { var n="model.gguf"; context.contentResolver.query(uri, null, null, null, null)?.use { c -> if(c.moveToFirst()){ val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0)n=c.getString(i) } }; return n.replace(Regex("[^A-Za-z0-9._-]"), "_") }

  @PluginMethod fun loadModel(call: PluginCall) {
    val path=call.getString("path") ?: run { call.reject("path required"); return }
    val ctx=call.getInt("context", 1024)!!.coerceIn(256,2048); val threads=call.getInt("threads", 2)!!.coerceIn(1,4)
    io.execute { try { if (loadedModelPath != path) { LlamaRuntime.unload(); LlamaRuntime.load(path, ctx, threads); loadedModelPath = path }; call.resolve(JSObject().put("loaded",true).put("model",File(path).name)) } catch(e:Exception){ loadedModelPath = null; call.reject("Model load failed: ${e.message}") } }
  }
  @PluginMethod fun unloadModel(call: PluginCall) { io.execute { LlamaRuntime.unload(); loadedModelPath = null; call.resolve() } }
  @PluginMethod fun generate(call: PluginCall) {
    val prompt=call.getString("prompt") ?: ""; val max=call.getInt("maxTokens",256)!!.coerceIn(16,512); val temp=call.getDouble("temperature",0.7)!!.coerceIn(0.0,1.5)
    io.execute { try { val answer=LlamaRuntime.generate(prompt,max,temp); call.resolve(JSObject().put("text",answer)) } catch(e:Exception){ call.reject("Inference failed: ${e.message}") } }
  }

  @PluginMethod fun startListening(call: PluginCall) {
    if (getPermissionState("microphone") != PermissionState.GRANTED) { requestPermissionForAlias("microphone", call, "micPermission"); return }
    startVosk(call)
  }
  @PermissionCallback private fun micPermission(call: PluginCall) { if(getPermissionState("microphone")==PermissionState.GRANTED) startVosk(call) else call.reject("Microphone permission denied") }
  private fun startVosk(call: PluginCall) {
    val modelDir=File(context.filesDir,"vosk-model-bn")
    if(!modelDir.exists()) { call.reject("Offline Bengali Vosk model missing. Install vosk-model-bn in app files first."); return }
    io.execute { try {
      if(speechModel==null) speechModel=Model(modelDir.absolutePath)
      val rec=Recognizer(speechModel,16000.0f)
      speechService=SpeechService(rec,16000.0f)
      speechService?.startListening(object: org.vosk.android.RecognitionListener {
        override fun onPartialResult(hypothesis:String) { notifyListeners("speechPartial", JSObject().put("text",hypothesis)) }
        override fun onResult(hypothesis:String) { speechResult += extractText(hypothesis)+" " }
        override fun onFinalResult(hypothesis:String) { speechResult += extractText(hypothesis)+" "; notifyListeners("speechFinal",JSObject().put("text",speechResult.trim())) }
        override fun onError(exception:Exception) { notifyListeners("speechError",JSObject().put("message",exception.message)) }
        override fun onTimeout() { }
      })
      call.resolve()
    } catch(e:Exception){ call.reject("STT start failed: ${e.message}") } }
  }
  private fun extractText(raw:String):String = try { org.json.JSONObject(raw).optString("text","") } catch(_:Exception){""}
  @PluginMethod fun stopListening(call: PluginCall) { speechService?.stop(); call.resolve(JSObject().put("text",speechResult.trim())); speechResult="" }
  @PluginMethod fun speak(call: PluginCall) { val text=call.getString("text") ?: ""; val lang=call.getString("language","bn-BD")!!; if(!ttsReady){call.reject("TTS unavailable");return}; tts?.language=if(lang.startsWith("bn")) Locale("bn","BD") else Locale.US; tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"notegenie"); call.resolve() }
  @PluginMethod fun stopSpeaking(call: PluginCall) { tts?.stop(); call.resolve() }

  @PluginMethod fun recognizeImage(call: PluginCall) {
    val path=call.getString("path") ?: run { call.reject("path required"); return }
    io.execute { try { val base=File(context.filesDir,"tessdata"); base.mkdirs(); val tess=TessBaseAPI(); if(!tess.init(context.filesDir.absolutePath,"ben+eng")){call.reject("Bengali OCR traineddata missing in files/tessdata");return@execute}; val bmp=BitmapFactory.decodeFile(path) ?: throw Exception("Image decode failed"); tess.setImage(bmp); val text=tess.utF8Text ?: ""; tess.recycle(); bmp.recycle(); call.resolve(JSObject().put("text",text)) } catch(e:Exception){call.reject("OCR failed: ${e.message}")} }
  }
  @PluginMethod fun extractPdf(call: PluginCall) {
    val path=call.getString("path") ?: run { call.reject("path required"); return }; val max=call.getInt("maxPages",30)!!.coerceIn(1,100)
    io.execute { try { val pfd=ParcelFileDescriptor.open(File(path),ParcelFileDescriptor.MODE_READ_ONLY); val pdf=PdfRenderer(pfd); val out=StringBuilder(); val count=minOf(pdf.pageCount,max)
      for(i in 0 until count){ val page=pdf.openPage(i); val bmp=Bitmap.createBitmap(page.width.coerceAtMost(1800),page.height.coerceAtMost(2400),Bitmap.Config.ARGB_8888); page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); val tess=TessBaseAPI(); if(tess.init(context.filesDir.absolutePath,"ben+eng")){tess.setImage(bmp);out.append("\n--- Page ${i+1} ---\n").append(tess.utF8Text ?: "");}; tess.recycle(); bmp.recycle(); page.close() }
      pdf.close();pfd.close();call.resolve(JSObject().put("text",out.toString()).put("pages",count))
    } catch(e:Exception){call.reject("PDF OCR failed: ${e.message}")} }
  }
  @PluginMethod fun pickDocument(call: PluginCall) { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("image/*","application/pdf","text/plain"))}; startActivityForResult(call,i,"documentPicked") }
  @ActivityCallback private fun documentPicked(call:PluginCall,result:ActivityResult){
    if(result.resultCode!=android.app.Activity.RESULT_OK){call.reject("Cancelled");return}
    val uri=result.data?.data?:run{call.reject("No document");return}
    io.execute{try{val name=queryName(uri);val mime=context.contentResolver.getType(uri)?:"application/octet-stream";val f=File(context.cacheDir,"picked_${System.currentTimeMillis()}_${name}");context.contentResolver.openInputStream(uri)!!.use{input->f.outputStream().use{input.copyTo(it)}};call.resolve(JSObject().put("path",f.absolutePath).put("mimeType",mime).put("name",name))}catch(e:Exception){call.reject(e.message)}}
  }
  @PluginMethod fun pickImage(call: PluginCall) { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)}; startActivityForResult(call,i,"imagePicked") }
  @ActivityCallback private fun imagePicked(call:PluginCall,result:ActivityResult){if(result.resultCode!=android.app.Activity.RESULT_OK){call.reject("Cancelled");return};val uri=result.data?.data?:run{call.reject("No image");return};io.execute{try{val f=File(context.cacheDir,"scan_${System.currentTimeMillis()}.jpg");context.contentResolver.openInputStream(uri)!!.use{input->f.outputStream().use{input.copyTo(it)}};call.resolve(JSObject().put("path",f.absolutePath))}catch(e:Exception){call.reject(e.message)}}}
  override fun handleOnDestroy() { speechService?.stop(); speechModel?.close(); tts?.shutdown(); LlamaRuntime.unload(); loadedModelPath = null; io.shutdown() }
}
