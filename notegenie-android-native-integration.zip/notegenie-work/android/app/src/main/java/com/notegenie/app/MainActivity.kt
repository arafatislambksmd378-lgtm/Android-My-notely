package com.notegenie.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import com.notegenie.app.plugins.NoteGenieNativePlugin

class MainActivity : BridgeActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    registerPlugin(NoteGenieNativePlugin::class.java)
    super.onCreate(savedInstanceState)
  }
}
