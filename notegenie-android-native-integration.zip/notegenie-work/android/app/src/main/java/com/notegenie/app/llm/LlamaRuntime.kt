package com.notegenie.app.llm

object LlamaRuntime {
  init { System.loadLibrary("notegenie_llama") }
  external fun nativeLoad(path: String, context: Int, threads: Int): Boolean
  external fun nativeGenerate(prompt: String, maxTokens: Int, temperature: Float): String
  external fun nativeUnload()
  @Synchronized fun load(path:String, context:Int, threads:Int) { if(!nativeLoad(path,context,threads)) error("llama.cpp could not load this GGUF model") }
  @Synchronized fun generate(prompt:String,maxTokens:Int,temperature:Double):String = nativeGenerate(prompt,maxTokens,temperature.toFloat())
  @Synchronized fun unload() { nativeUnload() }
}
