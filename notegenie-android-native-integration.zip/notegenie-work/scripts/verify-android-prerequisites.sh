#!/usr/bin/env bash
set -euo pipefail
for cmd in node npm java; do command -v "$cmd" >/dev/null || { echo "Missing: $cmd"; exit 1; }; done
[ -n "${ANDROID_HOME:-}" ] || { echo 'ANDROID_HOME is not set'; exit 1; }
[ -d "$ANDROID_HOME/platforms/android-35" ] || { echo 'Install Android SDK Platform 35'; exit 1; }
[ -d "$ANDROID_HOME/ndk" ] || { echo 'Install Android NDK'; exit 1; }
[ -f android/app/src/main/assets/tessdata/ben.traineddata ] || echo 'WARNING: Bengali Tesseract data missing'
[ -f android/app/src/main/assets/tessdata/eng.traineddata ] || echo 'WARNING: English Tesseract data missing'
[ -d android/app/src/main/assets/vosk-model-bn/conf ] || echo 'WARNING: Bengali Vosk model missing'
echo 'Prerequisite check complete. Run npm install && npm run build && npx cap sync android.'
