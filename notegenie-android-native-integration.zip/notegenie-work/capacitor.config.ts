import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.notegenie.app', appName: 'NoteGenie AI', webDir: 'dist', bundledWebRuntime: false, android: { allowMixedContent: false } };
export default config;
