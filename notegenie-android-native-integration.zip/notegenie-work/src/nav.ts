import type { Mode } from './ai';

export type Route =
  | { name: 'home' }
  | { name: 'editor'; id: string }
  | { name: 'notebook'; id: string }
  | { name: 'chat'; mode?: Mode }
  | { name: 'settings' }
  | { name: 'draw' }
  | { name: 'scan' }
  | { name: 'voice' }
  | { name: 'search' };

export type Nav = {
  go: (r: Route) => void;
  replace: (r: Route) => void;
  back: () => void;
};
