import { isNative, Native } from '../native';
import { useRef, useState } from 'react';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { actions, useStore, type Model } from '../store';
import { Avatar, ConfirmDialog, PromptDialog, TopBar, toast } from '../ui';

const LOW_RAM_LIMIT = 1500;

function ModelCard({ m, active }: { m: Model; active: boolean }) {
  const heavy = m.ramMb > LOW_RAM_LIMIT;
  return (
    <div className={`rounded-2xl border p-3 ${active ? 'border-[#6B4EFF] bg-[#F7F5FF]' : 'border-gray-200 bg-white'}`}>
      <div className="flex items-start gap-3">
        <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-[#6B4EFF] text-white' : 'bg-gray-100 text-gray-600'}`}>
          <Icon name="cpu" size={20} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm font-semibold">{m.name}</span>
            {active && <span className="rounded-full bg-[#00C853] px-2 py-0.5 text-[10px] font-bold text-white">ACTIVE</span>}
          </div>
          <div className="truncate text-[11px] text-gray-500">{m.file}</div>
          <div className="mt-1 flex flex-wrap gap-1.5 text-[10px] font-semibold">
            <span className="rounded-full bg-gray-100 px-2 py-0.5 text-gray-600">{m.quant} · 4-bit</span>
            <span className="rounded-full bg-gray-100 px-2 py-0.5 text-gray-600">{m.sizeMb >= 1000 ? (m.sizeMb / 1000).toFixed(1) + ' GB' : m.sizeMb + ' MB'}</span>
            <span className={`rounded-full px-2 py-0.5 ${heavy ? 'bg-[#FFF3C4] text-[#8a6d00]' : 'bg-[#E3F8EA] text-[#007a33]'}`}>~{(m.ramMb / 1000).toFixed(1)} GB RAM</span>
          </div>
          {heavy && <div className="mt-1 text-[11px] text-[#8a6d00]">⚠ Above 1.5 GB — not recommended on 3 GB devices.</div>}
        </div>
      </div>
      {m.status === 'downloading' && (
        <div className="mt-3">
          <div className="h-2 overflow-hidden rounded-full bg-gray-100">
            <div className="h-full rounded-full bg-[#6B4EFF] transition-all" style={{ width: m.progress + '%' }} />
          </div>
          <div className="mt-1 flex justify-between text-[11px] text-gray-500">
            <span>Downloading… {Math.round(m.progress)}%</span>
            <button onClick={() => actions.patchModel(m.id, { status: 'available', progress: 0 })} className="font-semibold text-red-500">Cancel</button>
          </div>
        </div>
      )}
      <div className="mt-3 flex gap-2">
        {m.status === 'available' && (
          <button onClick={() => isNative ? Native.importModel().then((v) => { actions.importModel(v); toast(`Imported ${v.name}`); }).catch((e) => toast(String(e))) : toast('Install the Android build to import a GGUF model.')} className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-[#6B4EFF] py-2 text-xs font-semibold text-white">
            <Icon name="upload" size={14} /> Import GGUF
          </button>
        )}
        {m.status === 'installed' && !active && (
          <button
            onClick={() => {
              actions.setActiveModel(m.id);
              toast(`Switched to ${m.name}`);
            }}
            className="flex-1 rounded-full bg-[#6B4EFF] py-2 text-xs font-semibold text-white"
          >
            Use this model
          </button>
        )}
        {m.status === 'installed' && (
          <button onClick={() => actions.removeModel(m.id)} className="rounded-full bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-700">
            {m.imported ? 'Remove' : 'Uninstall'}
          </button>
        )}
      </div>
    </div>
  );
}

export default function Settings({ nav }: { nav: Nav }) {
  const { profile, models, activeModelId, settings, notes } = useStore();
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState(false);
  const [reset, setReset] = useState(false);
  const active = models.find((m) => m.id === activeModelId);
  const heap = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory?.usedJSHeapSize;
  const storageKb = Math.round((localStorage.getItem('notegenie.v1')?.length ?? 0) / 1024);

  return (
    <div className="flex h-full flex-col bg-[#FAFAFE]">
      <TopBar title="Settings" onBack={nav.back} />
      <div className="min-h-0 flex-1 space-y-5 overflow-y-auto p-4 pb-10">
        <div className="flex items-center gap-3 rounded-3xl bg-white p-4 shadow-sm">
          <Avatar name={profile.name} size={52} />
          <div className="flex-1">
            <div className="font-bold">{profile.name}</div>
            <div className="text-xs text-gray-500">{notes.length} pages · stored only on this device</div>
          </div>
          <button onClick={() => setName(true)} className="rounded-full bg-[#EFEBFF] px-4 py-2 text-xs font-semibold text-[#6B4EFF]">Edit</button>
        </div>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-base font-bold">Local AI models</h3>
            <button onClick={() => isNative ? Native.importModel().then((m) => { actions.importModel({ name: m.name, size: m.size, path: m.path } as File); toast(`Imported ${m.name}`); }).catch((e) => toast(String(e))) : fileRef.current?.click()} className="flex items-center gap-1 rounded-full bg-[#6B4EFF] px-3 py-1.5 text-xs font-semibold text-white">
              <Icon name="upload" size={14} /> Import .gguf
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".gguf"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                if (!/\.gguf$/i.test(f.name)) toast('Please choose a .gguf file');
                else toast('Use the Android app to import and load a real GGUF model.');
                e.target.value = '';
              }}
            />
          </div>
          <p className="mb-3 text-xs text-gray-500">Engine: llama.cpp · 4-bit quantized GGUF · mmap loading. Only one model is kept in RAM at a time.</p>
          <div className="space-y-3">
            {models.map((m) => (
              <ModelCard key={m.id} m={m} active={m.id === activeModelId} />
            ))}
          </div>
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-sm">
          <h3 className="mb-3 text-base font-bold">Inference settings</h3>
          <label className="block">
            <div className="flex justify-between text-sm"><span className="font-medium">Context window</span><span className="font-semibold text-[#6B4EFF]">{settings.ctx} tokens</span></div>
            <input type="range" min={512} max={2048} step={256} value={settings.ctx} onChange={(e) => actions.setSettings({ ctx: +e.target.value })} className="mt-2 w-full accent-[#6B4EFF]" />
            <div className="text-[11px] text-gray-500">Hard-capped at 2048 to prevent memory overflow on 3 GB devices.</div>
          </label>
          <label className="mt-4 block">
            <div className="flex justify-between text-sm"><span className="font-medium">CPU threads</span><span className="font-semibold text-[#6B4EFF]">{settings.threads}</span></div>
            <input type="range" min={1} max={4} step={1} value={settings.threads} onChange={(e) => actions.setSettings({ threads: +e.target.value })} className="mt-2 w-full accent-[#6B4EFF]" />
          </label>
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-sm">
          <h3 className="mb-3 text-base font-bold">Performance audit</h3>
          <div className="space-y-2.5 text-sm">
            {[
              ['Active model', active?.name ?? '—'],
              ['Estimated model RAM', active ? `${(active.ramMb / 1000).toFixed(2)} GB` : '—'],
              ['Budget (3 GB device)', active && active.ramMb <= LOW_RAM_LIMIT ? '✅ Within 1.5 GB' : '⚠ Over 1.5 GB'],
              ['JS heap in use', heap ? `${(heap / 1048576).toFixed(1)} MB` : 'n/a'],
              ['Notes database', `${storageKb} KB`],
              ['Inference thread', 'Background worker'],
              ['List loading', 'Paginated (8 per page)'],
              ['Images', 'JPEG ≤1280px, 70%'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3"><span className="text-gray-500">{k}</span><span className="text-right font-medium">{v}</span></div>
            ))}
          </div>
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-sm">
          <h3 className="mb-1 text-base font-bold">Privacy</h3>
          <p className="text-xs text-gray-500">Notes, chats and models never leave this device. No account, no cloud.</p>
          <button onClick={() => setReset(true)} className="mt-3 rounded-full bg-red-50 px-4 py-2 text-xs font-semibold text-red-600">Reset app data</button>
        </section>
      </div>
      {name && <PromptDialog title="Your name" initial={profile.name} onSubmit={actions.setProfileName} onClose={() => setName(false)} />}
      {reset && <ConfirmDialog title="Reset everything?" body="All notes, notebooks and chats will be replaced with the sample data." confirm="Reset" onYes={() => { actions.resetAll(); toast('App data reset'); }} onClose={() => setReset(false)} />}
    </div>
  );
}
