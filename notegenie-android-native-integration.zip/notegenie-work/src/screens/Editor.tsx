import { useEffect, useRef, useState } from 'react';
import { summarize, translate } from '../ai';
import { exportNote, htmlToText, type Fmt } from '../export';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { speak, stopSpeaking, sttSupported, useSTT } from '../speech';
import { actions, useStore } from '../store';
import { ConfirmDialog, IconBtn, Sheet, SheetItem, TINTS, toast } from '../ui';

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export default function Editor({ id, nav }: { id: string; nav: Nav }) {
  const { notes, notebooks } = useStore();
  const note = notes.find((n) => n.id === id);
  const nb = notebooks.find((b) => b.id === note?.notebookId);
  const ref = useRef<HTMLDivElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [title, setTitle] = useState(note?.title ?? '');
  const [sheet, setSheet] = useState<null | 'export' | 'move' | 'ai' | 'color'>(null);
  const [del, setDel] = useState(false);
  const [busy, setBusy] = useState('');
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    if (ref.current && note) ref.current.innerHTML = note.html;
    return () => {
      clearTimeout(timer.current);
      stopSpeaking();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const flush = () => {
    clearTimeout(timer.current);
    if (ref.current) actions.updateNote(id, { html: ref.current.innerHTML });
  };
  const schedule = () => {
    clearTimeout(timer.current);
    timer.current = setTimeout(flush, 500);
  };

  const stt = useSTT((text) => {
    ref.current?.insertAdjacentHTML('beforeend', `<div>${esc(text)}</div>`);
    flush();
  });

  if (!note) return <div className="p-6">Note not found</div>;

  const text = () => htmlToText(ref.current?.innerHTML ?? '');

  const exit = () => {
    const empty = !title.trim() && !text() && !ref.current?.querySelector('img');
    if (empty) actions.deleteNote(id);
    else flush();
    nav.back();
  };

  const cmd = (c: string, v?: string) => {
    ref.current?.focus();
    document.execCommand(c, false, v);
    schedule();
  };
  const heading = (tag: 'h1' | 'h2') => {
    ref.current?.focus();
    const cur = String(document.queryCommandValue('formatBlock')).toLowerCase();
    document.execCommand('formatBlock', false, cur === tag ? 'div' : tag);
    schedule();
  };
  const checklist = () => {
    ref.current?.focus();
    document.execCommand('insertHTML', false, '<div class="chk"><input type="checkbox">\u200b</div>');
    schedule();
  };

  const onEditorClick = (e: React.MouseEvent) => {
    const t = e.target as HTMLElement;
    if (t instanceof HTMLInputElement && t.type === 'checkbox') {
      if (t.checked) t.setAttribute('checked', '');
      else t.removeAttribute('checked');
      schedule();
    }
  };

  const doExport = async (fmt: Fmt, share: boolean) => {
    flush();
    try {
      setBusy('Preparing ' + fmt.toUpperCase() + '…');
      const r = await exportNote(title, ref.current?.innerHTML ?? '', fmt, share);
      toast(r === 'pdf' ? 'Choose “Save as PDF” in the print dialog' : r === 'shared' ? 'Shared' : `Saved ${fmt.toUpperCase()} to downloads`);
    } catch {
      toast('Export failed');
    } finally {
      setBusy('');
      setSheet(null);
    }
  };

  const aiAction = async (kind: 'sum' | 'explain' | 'en' | 'bn') => {
    const t = text();
    setSheet(null);
    if (t.length < 3) return toast('Write something first');
    setBusy('Local AI is thinking…');
    await new Promise((r) => setTimeout(r, 700));
    const out = kind === 'sum' ? summarize(t) : kind === 'explain' ? summarize(t, true) : translate(t, kind);
    ref.current?.insertAdjacentHTML('beforeend', `<div class="ai-block">✨ ${esc(out)}</div><div><br></div>`);
    flush();
    setBusy('');
    toast('Added to your note');
  };

  const toggleTTS = () => {
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
      return;
    }
    const t = (title + '. ' + text()).trim();
    if (!t || !speak(t)) return toast('Text-to-speech not available');
    setSpeaking(true);
    const iv = setInterval(() => {
      if (!window.speechSynthesis.speaking) {
        setSpeaking(false);
        clearInterval(iv);
      }
    }, 600);
  };

  const toggleMic = () => {
    if (stt.listening) return stt.stop();
    if (!sttSupported || !stt.start()) toast('Speech recognition is not supported in this browser');
  };

  const tint = TINTS[note.tint] ?? TINTS.white;

  return (
    <div className="relative flex h-full flex-col bg-white">
      <div className="flex shrink-0 items-center gap-0.5 border-b border-gray-100 px-1.5 py-2">
        <IconBtn icon="back" label="Back" onClick={exit} />
        <button onClick={() => setSheet('move')} className="flex min-w-0 flex-1 items-center gap-1.5 rounded-full bg-gray-50 px-3 py-1.5 text-left active:bg-gray-100">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md text-white" style={{ background: nb?.color ?? '#999' }}>
            <Icon name="book" size={11} />
          </span>
          <span className="truncate text-xs font-semibold text-gray-700">{nb?.name ?? 'Unfiled'}</span>
          <Icon name="down" size={14} className="shrink-0 text-gray-400" />
        </button>
        <IconBtn icon="volume" label="Read aloud" active={speaking} onClick={toggleTTS} />
        <IconBtn icon="sparkles" label="AI" color="#6B4EFF" onClick={() => setSheet('ai')} />
        <IconBtn icon="share" label="Export" onClick={() => setSheet('export')} />
        <IconBtn icon="trash" label="Delete" onClick={() => setDel(true)} />
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-6 pt-4">
        <div className="mb-3 h-1.5 w-14 rounded-full" style={{ background: tint.border }} />
        <input
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
            actions.updateNote(id, { title: e.target.value });
          }}
          placeholder="Title"
          className="w-full bg-transparent text-[26px] font-bold leading-tight outline-none placeholder:text-gray-300"
        />
        <div className="mb-3 mt-1 text-xs text-gray-400">Autosaved on this device</div>
        <div
          ref={ref}
          className="editor"
          contentEditable
          suppressContentEditableWarning
          onInput={schedule}
          onBlur={flush}
          onClick={onEditorClick}
          data-placeholder="Start typing…"
        />
        {stt.listening && stt.interim && <div className="mt-2 rounded-xl bg-[#EFEBFF] px-3 py-2 text-sm text-[#6B4EFF]">🎙 {stt.interim}</div>}
      </div>

      {/* formatting toolbar */}
      <div className="flex shrink-0 items-center gap-0.5 overflow-x-auto border-t border-gray-100 bg-white px-2 py-1.5">
        <IconBtn icon="bold" label="Bold" onClick={() => cmd('bold')} />
        <IconBtn icon="italic" label="Italic" onClick={() => cmd('italic')} />
        <IconBtn icon="underline" label="Underline" onClick={() => cmd('underline')} />
        <span className="mx-1 h-6 w-px bg-gray-200" />
        {(['h1', 'h2'] as const).map((h) => (
          <button key={h} onMouseDown={(e) => e.preventDefault()} onClick={() => heading(h)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-extrabold text-gray-700 active:bg-gray-100">
            {h.toUpperCase()}
          </button>
        ))}
        <IconBtn icon="list" label="Bullets" onClick={() => cmd('insertUnorderedList')} />
        <IconBtn icon="check" label="Checklist" onClick={checklist} />
        <span className="mx-1 h-6 w-px bg-gray-200" />
        <IconBtn icon="mic" label="Dictate" active={stt.listening} color={stt.listening ? '#E53935' : undefined} onClick={toggleMic} />
        <IconBtn icon="undo" label="Undo" onClick={() => cmd('undo')} />
      </div>

      {busy && (
        <div className="absolute inset-0 z-[70] flex items-center justify-center bg-white/70">
          <div className="flex items-center gap-3 rounded-2xl bg-white px-5 py-3 shadow-xl">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-[#6B4EFF] border-t-transparent" />
            <span className="text-sm font-medium">{busy}</span>
          </div>
        </div>
      )}

      {sheet === 'export' && (
        <Sheet title="Export & share" onClose={() => setSheet(null)}>
          {([
            ['txt', 'Plain text (.txt)', 'file', '#2979FF'],
            ['pdf', 'PDF document', 'file', '#E53935'],
            ['docx', 'Word document (.docx)', 'file', '#2979FF'],
            ['xlsx', 'Excel sheet (.xlsx)', 'table', '#00C853'],
          ] as [Fmt, string, string, string][]).map(([f, label, icon, color]) => (
            <SheetItem
              key={f}
              icon={icon}
              label={label}
              color={color}
              onClick={() => doExport(f, false)}
              right={
                <span
                  role="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    doExport(f, true);
                  }}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-[#EFEBFF] text-[#6B4EFF]"
                >
                  <Icon name="share" size={17} />
                </span>
              }
            />
          ))}
          <p className="px-2 pt-2 text-xs text-gray-500">Tap a row to save, or the share icon to open the share sheet.</p>
        </Sheet>
      )}
      {sheet === 'move' && (
        <Sheet title="Move to notebook" onClose={() => setSheet(null)}>
          {notebooks.map((b) => (
            <SheetItem
              key={b.id}
              icon="book"
              label={b.name}
              color={b.color}
              right={b.id === note.notebookId ? <Icon name="check" size={18} className="text-[#00C853]" /> : undefined}
              onClick={() => {
                actions.moveNote(id, b.id);
                setSheet(null);
                toast(`Moved to ${b.name}`);
              }}
            />
          ))}
        </Sheet>
      )}
      {sheet === 'ai' && (
        <Sheet title="Local AI assistant" onClose={() => setSheet(null)}>
          <SheetItem icon="sparkles" label="Summarize (বাংলায় সারসংক্ষেপ)" onClick={() => aiAction('sum')} />
          <SheetItem icon="book" label="Explain the concept" color="#FFB300" onClick={() => aiAction('explain')} />
          <SheetItem icon="globe" label="Translate → English" color="#2979FF" onClick={() => aiAction('en')} />
          <SheetItem icon="globe" label="Translate → বাংলা" color="#00C853" onClick={() => aiAction('bn')} />
          <SheetItem icon="chat" label="Open AI chat" color="#FF5C8A" onClick={() => { flush(); nav.go({ name: 'chat' }); }} />
          <SheetItem icon="sparkles" label="Page color" color="#FFB300" onClick={() => setSheet('color')} />
        </Sheet>
      )}
      {sheet === 'color' && (
        <Sheet title="Page color" onClose={() => setSheet(null)}>
          <div className="flex justify-around py-3">
            {(Object.keys(TINTS) as (keyof typeof TINTS)[]).map((k) => (
              <button
                key={k}
                aria-label={k}
                onClick={() => {
                  actions.updateNote(id, { tint: k as never });
                  setSheet(null);
                }}
                className="h-12 w-12 rounded-full border-2"
                style={{ background: TINTS[k].bg, borderColor: note.tint === k ? '#6B4EFF' : TINTS[k].border }}
              />
            ))}
          </div>
        </Sheet>
      )}
      {del && (
        <ConfirmDialog
          title="Delete this page?"
          body="This cannot be undone."
          onYes={() => {
            actions.deleteNote(id);
            toast('Page deleted');
            nav.back();
          }}
          onClose={() => setDel(false)}
        />
      )}
    </div>
  );
}
