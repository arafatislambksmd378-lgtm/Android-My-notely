import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { actions, fmtDate, stripHtml, useStore, type Note, type Notebook } from '../store';
import { Avatar, ConfirmDialog, PromptDialog, Sheet, SheetItem, TINTS, toast } from '../ui';

export function NotebookBadge({ nb, size = 36 }: { nb?: Notebook; size?: number }) {
  return (
    <span
      className="flex shrink-0 items-center justify-center rounded-xl text-white"
      style={{ width: size, height: size, background: nb?.color ?? '#999' }}
    >
      <Icon name="book" size={size * 0.52} />
    </span>
  );
}

export function NoteCard({ note, nb, onClick }: { note: Note; nb?: Notebook; onClick: () => void }) {
  const t = TINTS[note.tint] ?? TINTS.white;
  const snippet = stripHtml(note.html);
  return (
    <button
      onClick={onClick}
      className="flex min-h-[160px] flex-col rounded-3xl border p-3.5 text-left transition active:scale-[0.97]"
      style={{ background: t.bg, borderColor: t.border }}
    >
      <div className="flex items-center gap-1.5">
        <span className="flex h-5 w-5 items-center justify-center rounded-md text-white" style={{ background: nb?.color ?? '#999' }}>
          <Icon name="book" size={11} />
        </span>
        <span className="truncate text-[11px] font-semibold text-gray-600">{nb?.name ?? 'Unfiled'}</span>
      </div>
      <div className="mt-2 line-clamp-2 text-[15px] font-bold leading-snug">{note.title || 'Untitled page'}</div>
      <div className="mt-1 line-clamp-3 flex-1 text-[12.5px] leading-snug text-gray-600">{snippet || 'Empty page'}</div>
      <div className="mt-2 text-[11px] font-medium text-gray-500">{fmtDate(note.updatedAt)}</div>
    </button>
  );
}

const PAGE = 8;

function RecentGrid({ nav }: { nav: Nav }) {
  const { notes, notebooks } = useStore();
  const [limit, setLimit] = useState(PAGE);
  const sorted = useMemo(() => [...notes].sort((a, b) => b.updatedAt - a.updatedAt), [notes]);
  const visible = sorted.slice(0, limit);
  const sentinel = useRef<HTMLDivElement>(null);

  // lazy pagination: render next page when the sentinel scrolls into view
  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver((e) => e[0].isIntersecting && setLimit((l) => l + PAGE), { rootMargin: '200px' });
    io.observe(el);
    return () => io.disconnect();
  }, [visible.length]);

  return (
    <div className="px-4 pb-6">
      <div className="mb-3 flex items-baseline justify-between">
        <h2 className="text-lg font-bold">Recent notes</h2>
        <span className="text-xs text-gray-500">{notes.length} pages</span>
      </div>
      {notes.length === 0 ? (
        <div className="py-16 text-center text-gray-500">
          <div className="text-4xl">📝</div>
          <p className="mt-2 text-sm">No notes yet. Tap “+ Page” to start.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {visible.map((n) => (
            <NoteCard key={n.id} note={n} nb={notebooks.find((b) => b.id === n.notebookId)} onClick={() => nav.go({ name: 'editor', id: n.id })} />
          ))}
        </div>
      )}
      {visible.length < sorted.length && <div ref={sentinel} className="h-10 text-center text-xs text-gray-400">Loading…</div>}
    </div>
  );
}

function NotebookRow({ nb, nav, onMenu }: { nb: Notebook; nav: Nav; onMenu: () => void }) {
  const { notes } = useStore();
  const count = notes.filter((n) => n.notebookId === nb.id).length;
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-gray-100 bg-white p-3 shadow-[0_1px_4px_rgba(60,40,140,0.06)]">
      <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => nav.go({ name: 'notebook', id: nb.id })}>
        <NotebookBadge nb={nb} size={44} />
        <span className="min-w-0">
          <span className="block truncate text-[15px] font-semibold">{nb.name}</span>
          <span className="block text-xs text-gray-500">{count} {count === 1 ? 'page' : 'pages'}</span>
        </span>
      </button>
      <button onClick={onMenu} aria-label="Notebook options" className="flex h-9 w-9 items-center justify-center rounded-full text-gray-500 active:bg-gray-100">
        <Icon name="more" />
      </button>
    </div>
  );
}

function NotebooksList({ nav }: { nav: Nav }) {
  const { notebooks } = useStore();
  const [menu, setMenu] = useState<Notebook | null>(null);
  const [rename, setRename] = useState<Notebook | null>(null);
  const [del, setDel] = useState<Notebook | null>(null);
  const [openClosed, setOpenClosed] = useState(true);
  const open = notebooks.filter((n) => !n.closed);
  const closed = notebooks.filter((n) => n.closed);

  return (
    <div className="space-y-5 px-4 pb-28">
      <section>
        <h2 className="mb-2 text-lg font-bold">Notebooks</h2>
        <div className="space-y-2">
          {open.map((nb) => (
            <NotebookRow key={nb.id} nb={nb} nav={nav} onMenu={() => setMenu(nb)} />
          ))}
          {open.length === 0 && <p className="py-4 text-sm text-gray-500">No open notebooks.</p>}
        </div>
      </section>
      <section>
        <button onClick={() => setOpenClosed(!openClosed)} className="mb-2 flex w-full items-center gap-2 text-left">
          <Icon name="lock" size={18} className="text-gray-500" />
          <h2 className="flex-1 text-lg font-bold">Closed Notebooks</h2>
          <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-600">{closed.length}</span>
          <Icon name={openClosed ? 'down' : 'right'} size={18} className="text-gray-500" />
        </button>
        {openClosed && (
          <div className="space-y-2">
            {closed.map((nb) => (
              <NotebookRow key={nb.id} nb={nb} nav={nav} onMenu={() => setMenu(nb)} />
            ))}
          </div>
        )}
      </section>

      {menu && (
        <Sheet title={menu.name} onClose={() => setMenu(null)}>
          <SheetItem icon="plus" label="New page" onClick={() => { const id = actions.addNote(menu.id); setMenu(null); nav.go({ name: 'editor', id }); }} />
          <SheetItem icon="edit" label="Rename" color="#2979FF" onClick={() => { setRename(menu); setMenu(null); }} />
          <SheetItem icon="lock" label={menu.closed ? 'Open notebook' : 'Close notebook'} color="#FFB300" onClick={() => { actions.toggleClosed(menu.id); toast(menu.closed ? 'Notebook opened' : 'Notebook closed'); setMenu(null); }} />
          <SheetItem icon="trash" label="Delete" danger onClick={() => { setDel(menu); setMenu(null); }} />
        </Sheet>
      )}
      {rename && <PromptDialog title="Rename notebook" initial={rename.name} onSubmit={(v) => actions.renameNotebook(rename.id, v)} onClose={() => setRename(null)} />}
      {del && <ConfirmDialog title={`Delete “${del.name}”?`} body="All pages inside this notebook will be permanently deleted from this device." onYes={() => { actions.deleteNotebook(del.id); toast('Notebook deleted'); }} onClose={() => setDel(null)} />}
    </div>
  );
}

export default function Home({ nav, tab, setTab }: { nav: Nav; tab: 'home' | 'notebooks'; setTab: (t: 'home' | 'notebooks') => void }) {
  const { profile, notebooks } = useStore();
  const [more, setMore] = useState(false);
  const [newNb, setNewNb] = useState(false);

  const newPage = () => {
    const nb = notebooks.find((n) => !n.closed) ?? notebooks[0];
    if (!nb) {
      toast('Create a notebook first');
      setNewNb(true);
      return;
    }
    nav.go({ name: 'editor', id: actions.addNote(nb.id) });
  };

  const navItems = [
    { icon: 'plus', label: 'Page', onClick: newPage, primary: true },
    { icon: 'pen', label: 'Draw', onClick: () => nav.go({ name: 'draw' }) },
    { icon: 'camera', label: 'Scan', onClick: () => nav.go({ name: 'scan' }) },
    { icon: 'mic', label: 'Voice', onClick: () => nav.go({ name: 'voice' }) },
    { icon: 'more', label: 'More', onClick: () => setMore(true) },
  ];

  return (
    <div className="relative flex h-full flex-col bg-white">
      {/* app bar */}
      <div className="flex shrink-0 items-center gap-2 px-4 pb-2 pt-4">
        <Avatar name={profile.name} onClick={() => nav.go({ name: 'settings' })} />
        <div className="ml-1 flex-1">
          <div className="text-[11px] font-medium text-gray-500">Welcome back</div>
          <div className="-mt-0.5 text-base font-bold">Note<span className="text-[#6B4EFF]">Genie</span> AI</div>
        </div>
        <button aria-label="Search" onClick={() => nav.go({ name: 'search' })} className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-50 text-gray-700 active:bg-gray-100">
          <Icon name="search" size={21} />
        </button>
        <button aria-label="Settings" onClick={() => nav.go({ name: 'settings' })} className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-50 text-gray-700 active:bg-gray-100">
          <Icon name="settings" size={21} />
        </button>
      </div>

      {/* pill toggle */}
      <div className="shrink-0 px-4 pb-3 pt-1">
        <div className="flex rounded-full bg-gray-100 p-1">
          {(['home', 'notebooks'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 rounded-full py-2 text-sm font-semibold capitalize transition ${tab === t ? 'bg-[#6B4EFF] text-white shadow-md shadow-[#6B4EFF]/30' : 'text-gray-600'}`}
            >
              {t === 'home' ? 'Home' : 'Notebooks'}
            </button>
          ))}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto pb-24">{tab === 'home' ? <RecentGrid nav={nav} /> : <NotebooksList nav={nav} />}</div>

      {/* FAB */}
      {tab === 'notebooks' && (
        <button onClick={() => setNewNb(true)} className="absolute bottom-24 right-4 z-10 flex items-center gap-2 rounded-full bg-[#6B4EFF] px-5 py-3.5 text-sm font-semibold text-white shadow-xl shadow-[#6B4EFF]/40 active:scale-95">
          <Icon name="plus" size={18} /> Notebook
        </button>
      )}

      {/* bottom navigation */}
      <nav className="absolute inset-x-0 bottom-0 z-20 flex items-end justify-around border-t border-gray-100 bg-white/95 px-2 pb-3 pt-2 backdrop-blur">
        {navItems.map((it) => (
          <button key={it.label} onClick={it.onClick} className="flex w-16 flex-col items-center gap-1 active:scale-95">
            <span className={`flex items-center justify-center rounded-2xl ${it.primary ? 'h-11 w-11 bg-[#6B4EFF] text-white shadow-lg shadow-[#6B4EFF]/40' : 'h-11 w-11 text-gray-600'}`}>
              <Icon name={it.icon} size={22} />
            </span>
            <span className={`text-[11px] font-semibold ${it.primary ? 'text-[#6B4EFF]' : 'text-gray-500'}`}>{it.label}</span>
          </button>
        ))}
      </nav>

      {more && (
        <Sheet title="More" onClose={() => setMore(false)}>
          <SheetItem icon="chat" label="AI Chat (বাংলা)" sub="Ask, plan, write stories – fully offline" onClick={() => { setMore(false); nav.go({ name: 'chat' }); }} />
          <SheetItem icon="globe" label="Translate" sub="Bengali ⇄ English" color="#2979FF" onClick={() => { setMore(false); nav.go({ name: 'chat', mode: 'translate' }); }} />
          <SheetItem icon="table" label="Generate document" sub="AI table → PDF / Excel / DOCX" color="#00C853" onClick={() => { setMore(false); nav.go({ name: 'chat', mode: 'document' }); }} />
          <SheetItem icon="cpu" label="AI models & settings" sub="Import or switch .gguf models" color="#FFB300" onClick={() => { setMore(false); nav.go({ name: 'settings' }); }} />
          <SheetItem icon="plus" label="New notebook" color="#FF5C8A" onClick={() => { setMore(false); setNewNb(true); }} />
        </Sheet>
      )}
      {newNb && (
        <PromptDialog
          title="New notebook"
          confirm="Create"
          onSubmit={(v) => {
            actions.addNotebook(v);
            setTab('notebooks');
            toast('Notebook created');
          }}
          onClose={() => setNewNb(false)}
        />
      )}
    </div>
  );
}
