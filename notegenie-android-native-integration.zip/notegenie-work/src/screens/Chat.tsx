import { useEffect, useRef, useState } from 'react';
import { MAX_CTX, estimateTokens, generate, trimHistory, type Mode } from '../ai';
import { exportTable, exportText, type Fmt } from '../export';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { speak, sttSupported, useSTT } from '../speech';
import { actions, uid, useStore, type ChatMsg, type DocData } from '../store';
import { IconBtn, TopBar, toast } from '../ui';

const MODES: { id: Mode; label: string; icon: string; hint: string; samples: string[] }[] = [
  { id: 'chat', label: 'Chat', icon: 'chat', hint: 'বাংলায় প্রশ্ন করুন…', samples: ['একটি ছোট গল্প লেখো', 'অ্যাপের আর্কিটেকচার পরিকল্পনা করো', 'ভালো নোট নেওয়ার টিপস দাও'] },
  { id: 'translate', label: 'Translate', icon: 'globe', hint: 'Type text – Bengali ⇄ English', samples: ['How are you', 'আমি ভাত খাই', 'Thank you my friend'] },
  { id: 'summarize', label: 'Summarize', icon: 'sparkles', hint: 'Paste text to summarize…', samples: [] },
  { id: 'document', label: 'Document', icon: 'table', hint: 'e.g. মাসিক বাজেটের টেবিল বানাও', samples: ['মাসিক বাজেটের টেবিল বানাও', 'ক্লাস রুটিন তৈরি করো', 'প্রজেক্ট রিপোর্ট তৈরি করো'] },
];

function DocCard({ doc }: { doc: DocData }) {
  const run = async (f: Fmt) => {
    const r = await exportTable(doc, f, f !== 'pdf' && false);
    toast(r === 'pdf' ? 'Choose “Save as PDF” in the print dialog' : `Saved ${f.toUpperCase()}`);
  };
  return (
    <div className="mt-2 overflow-hidden rounded-2xl border border-gray-200 bg-white">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr>
              {doc.rows[0].map((c, i) => (
                <th key={i} className="whitespace-nowrap bg-[#6B4EFF] px-2.5 py-1.5 font-semibold text-white">{c}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {doc.rows.slice(1).map((r, i) => (
              <tr key={i} className={i % 2 ? 'bg-gray-50' : ''}>
                {r.map((c, j) => (
                  <td key={j} className="whitespace-nowrap px-2.5 py-1.5 text-gray-700">{c}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex gap-2 p-2">
        {([['pdf', 'PDF', '#E53935'], ['xlsx', 'Excel', '#00C853'], ['docx', 'DOCX', '#2979FF']] as [Fmt, string, string][]).map(([f, l, c]) => (
          <button key={f} onClick={() => run(f)} className="flex flex-1 items-center justify-center gap-1 rounded-full py-2 text-xs font-bold text-white active:opacity-80" style={{ background: c }}>
            <Icon name="download" size={14} /> {l}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function Chat({ nav, initialMode = 'chat' }: { nav: Nav; initialMode?: Mode }) {
  const { chat, models, activeModelId, settings, notebooks } = useStore();
  const model = models.find((m) => m.id === activeModelId);
  const [mode, setMode] = useState<Mode>(initialMode);
  const [input, setInput] = useState('');
  const [stream, setStream] = useState<string | null>(null);
  const abort = useRef<AbortController | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const ctx = Math.min(MAX_CTX, settings.ctx);
  const cfg = MODES.find((m) => m.id === mode)!;
  const used = trimHistory(chat, ctx).tokens;

  const stt = useSTT((t) => setInput((v) => (v ? v + ' ' : '') + t));

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [chat.length, stream]);
  useEffect(() => () => abort.current?.abort(), []);

  const send = async (override?: string) => {
    const text = (override ?? input).trim();
    if (!text || stream !== null) return;
    if (!model || model.status !== 'installed') return toast('Install and select a model in Settings first');
    setInput('');
    actions.pushChat({ id: uid(), role: 'user', text });
    setStream('');
    const ac = new AbortController();
    abort.current = ac;
    // context window guard: only the newest messages that fit are fed to the model
    trimHistory([...chat, { id: '', role: 'user', text }], ctx);
    try {
      const res = await generate(text, mode, (p) => setStream(p), ac.signal);
      actions.pushChat({ id: uid(), role: 'ai', text: res.text, doc: res.doc });
    } catch {
      /* stopped by user */
    } finally {
      setStream(null);
    }
  };

  const stop = () => abort.current?.abort();

  const saveToNote = (m: ChatMsg) => {
    const nb = notebooks.find((n) => !n.closed) ?? notebooks[0];
    if (!nb) return toast('No notebook available');
    const html = m.text.split('\n').map((l) => `<div>${l.replace(/&/g, '&amp;').replace(/</g, '&lt;') || '<br>'}</div>`).join('');
    const id = actions.addNote(nb.id, 'AI: ' + m.text.slice(0, 28).replace(/\n/g, ' '), html, 'purple');
    toast(`Saved to ${nb.name}`);
    nav.go({ name: 'editor', id });
  };

  return (
    <div className="flex h-full flex-col bg-white">
      <TopBar
        title={
          <span className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#6B4EFF] text-white"><Icon name="sparkles" size={17} /></span>
            <span className="leading-tight">
              <span className="block text-[15px]">NoteGenie AI</span>
              <span className="-mt-0.5 block truncate text-[10px] font-medium text-[#00C853]">● {model?.name ?? 'No model'} · offline</span>
            </span>
          </span>
        }
        onBack={nav.back}
        right={
          <>
            <IconBtn icon="trash" label="Clear chat" onClick={() => { actions.clearChat(); toast('Chat cleared'); }} />
            <IconBtn icon="cpu" label="Models" onClick={() => nav.go({ name: 'settings' })} />
          </>
        }
      />

      <div className="flex shrink-0 gap-2 overflow-x-auto px-3 py-2">
        {MODES.map((m) => (
          <button key={m.id} onClick={() => setMode(m.id)} className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold ${mode === m.id ? 'bg-[#6B4EFF] text-white' : 'bg-gray-100 text-gray-600'}`}>
            <Icon name={m.icon} size={14} /> {m.label}
          </button>
        ))}
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-3">
        {chat.length === 0 && stream === null && (
          <div className="px-2 pb-2 pt-8 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#EFEBFF] text-[#6B4EFF]"><Icon name="sparkles" size={30} /></div>
            <h3 className="mt-3 text-lg font-bold">আমি আপনার অফলাইন AI 👋</h3>
            <p className="mt-1 text-sm text-gray-500">সব কিছু আপনার ডিভাইসেই চলে। কিছু জিজ্ঞেস করুন বা নিচের একটি বেছে নিন।</p>
            <div className="mt-4 flex flex-col gap-2">
              {cfg.samples.map((s) => (
                <button key={s} onClick={() => send(s)} className="rounded-2xl border border-[#D5CBFF] bg-[#F7F5FF] px-4 py-2.5 text-left text-sm font-medium text-[#553BD9] active:bg-[#EFEBFF]">{s}</button>
              ))}
            </div>
          </div>
        )}
        {chat.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[88%] rounded-3xl px-4 py-2.5 text-[14.5px] leading-relaxed ${m.role === 'user' ? 'rounded-br-lg bg-[#6B4EFF] text-white' : 'rounded-bl-lg bg-[#F3F1FB]'}`}>
              <div className="whitespace-pre-wrap break-words">{m.doc ? m.text.split('\n\n')[0] : m.text.replace(/\*\*/g, '')}</div>
              {m.doc && <DocCard doc={m.doc} />}
              {m.role === 'ai' && (
                <div className="mt-2 flex gap-1 text-gray-500">
                  <button aria-label="Read aloud" onClick={() => speak(m.text.replace(/[*#•📝🔑💡📖🌐🏗️]/g, ''))} className="rounded-full p-1.5 active:bg-white"><Icon name="volume" size={16} /></button>
                  <button aria-label="Copy" onClick={() => { navigator.clipboard?.writeText(m.text); toast('Copied'); }} className="rounded-full p-1.5 active:bg-white"><Icon name="copy" size={16} /></button>
                  <button aria-label="Save to note" onClick={() => saveToNote(m)} className="rounded-full p-1.5 active:bg-white"><Icon name="file" size={16} /></button>
                  {!m.doc && <button aria-label="Export PDF" onClick={() => exportText('NoteGenie AI', m.text, 'pdf')} className="rounded-full p-1.5 active:bg-white"><Icon name="download" size={16} /></button>}
                </div>
              )}
            </div>
          </div>
        ))}
        {stream !== null && (
          <div className="flex justify-start">
            <div className="max-w-[88%] whitespace-pre-wrap break-words rounded-3xl rounded-bl-lg bg-[#F3F1FB] px-4 py-2.5 text-[14.5px] leading-relaxed">
              {stream || (
                <span className="flex gap-1 py-1"><span className="dot h-2 w-2 rounded-full bg-[#6B4EFF]" /><span className="dot h-2 w-2 rounded-full bg-[#6B4EFF]" /><span className="dot h-2 w-2 rounded-full bg-[#6B4EFF]" /></span>
              )}
            </div>
          </div>
        )}
        <div ref={bottom} />
      </div>

      <div className="shrink-0 border-t border-gray-100 bg-white px-3 pb-3 pt-2">
        <div className="mb-1.5 flex items-center justify-between px-1 text-[10px] text-gray-400">
          <span>Context {used + estimateTokens(input)}/{ctx} tokens</span>
          <span>{model?.quant} · {settings.threads} threads · bg worker</span>
        </div>
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            rows={1}
            placeholder={cfg.hint}
            className="max-h-28 min-h-11 flex-1 resize-none rounded-3xl bg-gray-100 px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-[#6B4EFF]/40"
          />
          <button
            aria-label="Voice input"
            onClick={() => (stt.listening ? stt.stop() : sttSupported ? stt.start() : toast('Speech recognition not supported here'))}
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${stt.listening ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            <Icon name="mic" size={20} />
          </button>
          {stream !== null ? (
            <button aria-label="Stop" onClick={stop} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gray-800 text-white"><Icon name="stop" size={18} /></button>
          ) : (
            <button aria-label="Send" onClick={() => send()} disabled={!input.trim()} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#6B4EFF] text-white shadow-lg shadow-[#6B4EFF]/30 disabled:opacity-40"><Icon name="send" size={19} /></button>
          )}
        </div>
      </div>
    </div>
  );
}
