import { useState } from 'react';
import { summarize } from '../ai';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { sttSupported, useSTT } from '../speech';
import { actions, useStore } from '../store';
import { TopBar, toast } from '../ui';

export default function Voice({ nav }: { nav: Nav }) {
  const { notebooks } = useStore();
  const [lang, setLang] = useState<'bn-BD' | 'en-US'>('bn-BD');
  const [text, setText] = useState('');
  const stt = useSTT((t) => setText((v) => (v ? v + ' ' : '') + t), lang);

  const toggle = () => {
    if (stt.listening) return stt.stop();
    if (!sttSupported) return toast('Speech recognition not supported in this browser – type below instead');
    if (!stt.start()) toast('Could not access the microphone');
  };

  // light "AI cleanup": trims, capitalizes and ends sentences with the right punctuation
  const cleanup = () => {
    const t = text.replace(/\s+/g, ' ').trim();
    if (!t) return;
    const end = lang === 'bn-BD' ? '।' : '.';
    const out = /[।.!?]$/.test(t) ? t : t + end;
    setText(lang === 'en-US' ? out.charAt(0).toUpperCase() + out.slice(1) : out);
    toast('Text polished by AI');
  };

  const save = (withSummary: boolean) => {
    if (!text.trim()) return toast('Nothing to save');
    const nb = notebooks.find((n) => !n.closed) ?? notebooks[0];
    if (!nb) return toast('Create a notebook first');
    const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const html = `<div>${esc(text)}</div>` + (withSummary ? `<div class="ai-block">✨ ${esc(summarize(text))}</div>` : '');
    const id = actions.addNote(nb.id, 'Voice note', html, 'yellow');
    toast('Saved as a new page');
    nav.replace({ name: 'editor', id });
  };

  return (
    <div className="flex h-full flex-col bg-white">
      <TopBar title="Voice to note" onBack={nav.back} />
      <div className="flex min-h-0 flex-1 flex-col items-center overflow-y-auto px-5 pb-6 pt-6">
        <div className="flex rounded-full bg-gray-100 p-1 text-xs font-semibold">
          {([['bn-BD', 'বাংলা'], ['en-US', 'English']] as const).map(([k, l]) => (
            <button key={k} onClick={() => { if (!stt.listening) setLang(k); }} className={`rounded-full px-4 py-1.5 ${lang === k ? 'bg-[#6B4EFF] text-white' : 'text-gray-600'}`}>{l}</button>
          ))}
        </div>

        <div className="relative my-8 flex h-40 w-40 items-center justify-center">
          {stt.listening && <span className="ring absolute h-28 w-28 rounded-full bg-[#6B4EFF]" />}
          {stt.listening && <span className="ring absolute h-28 w-28 rounded-full bg-[#6B4EFF]" style={{ animationDelay: '0.6s' }} />}
          <button onClick={toggle} aria-label="Record" className={`relative flex h-28 w-28 items-center justify-center rounded-full text-white shadow-2xl transition active:scale-95 ${stt.listening ? 'bg-red-500 shadow-red-500/40' : 'bg-[#6B4EFF] shadow-[#6B4EFF]/40'}`}>
            <Icon name={stt.listening ? 'stop' : 'mic'} size={42} />
          </button>
        </div>
        <div className="mb-3 text-sm font-medium text-gray-600">
          {stt.listening ? (lang === 'bn-BD' ? 'শুনছি… বাংলায় বলুন' : 'Listening… speak now') : 'Tap the mic and start speaking'}
        </div>
        {stt.interim && <div className="mb-2 w-full rounded-xl bg-[#EFEBFF] px-3 py-2 text-sm text-[#6B4EFF]">{stt.interim}</div>}

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={7}
          placeholder="Your transcript will appear here…"
          className="w-full rounded-2xl border border-gray-200 p-4 text-[15px] leading-relaxed outline-none focus:border-[#6B4EFF]"
        />
        <div className="mt-3 grid w-full grid-cols-2 gap-2">
          <button onClick={cleanup} className="flex items-center justify-center gap-2 rounded-2xl bg-[#EFEBFF] py-3 text-sm font-semibold text-[#6B4EFF]"><Icon name="sparkles" size={16} /> AI polish</button>
          <button onClick={() => setText('')} className="rounded-2xl bg-gray-100 py-3 text-sm font-semibold text-gray-700">Clear</button>
          <button onClick={() => save(false)} className="rounded-2xl bg-[#6B4EFF] py-3 text-sm font-semibold text-white">Save as note</button>
          <button onClick={() => save(true)} className="rounded-2xl bg-[#00C853] py-3 text-sm font-semibold text-white">Note + summary</button>
        </div>
        <p className="mt-4 text-center text-[11px] text-gray-400">Native build uses the offline Vosk Bengali model. Web preview uses the browser’s speech engine.</p>
      </div>
    </div>
  );
}
