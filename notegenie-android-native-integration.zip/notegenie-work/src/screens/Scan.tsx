import { isNative, Native } from '../native';
import { useRef, useState } from 'react';
import { generate, summarize, translate } from '../ai';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { compressImage } from '../speech';
import { actions, useStore } from '../store';
import { TopBar, toast } from '../ui';

/* eslint-disable @typescript-eslint/no-explicit-any */
async function ocr(file: Blob): Promise<string> {
  const TD = (window as any).TextDetector; // experimental browser-only fallback
  if (!TD) return '';
  try {
    const bmp = await createImageBitmap(file);
    const res = await new TD().detect(bmp);
    return res.map((r: any) => r.rawValue).join('\n');
  } catch {
    return '';
  }
}

export default function Scan({ nav }: { nav: Nav }) {
  const { notebooks } = useStore();
  const input = useRef<HTMLInputElement>(null);
  const [img, setImg] = useState('');
  const [info, setInfo] = useState('');
  const [text, setText] = useState('');
  const [result, setResult] = useState('');
  const [busy, setBusy] = useState('');

  const pick = async (f?: File) => {
    if (!f) return;
    setResult('');
    if (/\.txt$/i.test(f.name) || f.type === 'text/plain') {
      setImg('');
      setText(await f.text());
      setInfo(`${f.name} loaded`);
      return;
    }
    if (f.type === 'application/pdf') {
      toast('PDF OCR is available in the Android build; use the Android app to select this PDF');
      return;
    }
    setBusy('Compressing image…');
    try {
      const url = await compressImage(f);
      setImg(url);
      setInfo(`Compressed ${(f.size / 1024).toFixed(0)} KB → ${(url.length * 0.75 / 1024).toFixed(0)} KB`);
      setBusy('Recognizing text (OCR)…');
      const t = await ocr(f);
      setText(t);
      if (!t) toast('Auto-OCR unavailable in this browser. Type or paste the text.');
    } catch {
      toast('Could not read that image');
    }
    setBusy('');
  };

  const pickNative = async () => {
    try {
      setBusy('Opening document…');
      const doc = await Native.pickDocument();
      setInfo(doc.name);
      if (doc.mimeType === 'application/pdf' || doc.name.toLowerCase().endsWith('.pdf')) {
        setBusy('Extracting PDF pages with Bengali OCR…');
        const r = await Native.extractPdf({ path: doc.path, maxPages: 25 });
        setText(r.text); setImg('');
        if (!r.text.trim()) toast('No readable text found. This may be a scanned PDF or missing Bengali traineddata.');
      } else if (doc.mimeType.startsWith('image/')) {
        setBusy('Recognizing Bengali text…');
        const r = await Native.recognizeImage({ path: doc.path });
        setText(r.text); setImg('');
        if (!r.text.trim()) toast('No text found. Check Bengali OCR data installation.');
      } else {
        setText('Unsupported file type');
      }
    } catch (e) { toast(String(e)); }
    finally { setBusy(''); }
  };

  const run = async (kind: 'sum' | 'explain' | 'en' | 'bn') => {
    if (text.trim().length < 3) return toast('No text to analyze yet');
    setBusy('Local AI is analyzing…');
    try {
      if (isNative) {
        const prompt = kind === 'sum' ? `এই লেখাটির সারসংক্ষেপ করো:\n${text}` : kind === 'explain' ? `এই লেখাটি সহজ বাংলায় ব্যাখ্যা করো:\n${text}` : kind === 'en' ? `Translate this text into English:\n${text}` : `এই লেখাটি বাংলায় অনুবাদ করো:\n${text}`;
        const response = await generate(prompt, kind === 'sum' || kind === 'explain' ? 'summarize' : 'translate', () => undefined);
        setResult(response.text);
      } else {
        await new Promise((r) => setTimeout(r, 800));
        setResult(kind === 'sum' ? summarize(text) : kind === 'explain' ? summarize(text, true) : translate(text, kind));
      }
    } catch (e) { toast(String(e)); }
    finally { setBusy(''); }
  };

  const save = () => {
    const nb = notebooks.find((n) => !n.closed) ?? notebooks[0];
    if (!nb) return toast('Create a notebook first');
    const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const html =
      (img ? `<div><img src="${img}" alt="scan"></div>` : '') +
      (text ? text.split('\n').map((l) => `<div>${esc(l) || '<br>'}</div>`).join('') : '') +
      (result ? `<div class="ai-block">✨ ${esc(result)}</div>` : '');
    const id = actions.addNote(nb.id, 'Scanned document', html, 'green');
    toast('Saved as a new page');
    nav.replace({ name: 'editor', id });
  };

  return (
    <div className="flex h-full flex-col bg-white">
      <TopBar title="Scan & analyze" onBack={nav.back} right={(img || text) && <button onClick={save} className="mr-1 rounded-full bg-[#6B4EFF] px-4 py-2 text-sm font-semibold text-white">Save</button>} />
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 pb-8">
        <input ref={input} type="file" accept="image/*,.txt,application/pdf" capture="environment" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
        {!img && !text ? (
          <button onClick={() => isNative ? pickNative() : input.current?.click()} className="flex w-full flex-col items-center gap-3 rounded-3xl border-2 border-dashed border-[#D5CBFF] bg-[#F7F5FF] px-6 py-12 active:bg-[#EFEBFF]">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-[#6B4EFF] text-white shadow-lg shadow-[#6B4EFF]/30"><Icon name="camera" size={28} /></span>
            <span className="text-base font-bold">Scan a document</span>
            <span className="text-center text-xs text-gray-500">Take a photo or pick an image / .txt file. Text is extracted and the local AI explains it in Bengali.</span>
          </button>
        ) : (
          <button onClick={() => isNative ? pickNative() : input.current?.click()} className="flex items-center gap-2 rounded-full bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-700">
            <Icon name="camera" size={15} /> Scan another
          </button>
        )}
        {img && (
          <div>
            <img src={img} alt="Scanned" className="max-h-64 w-full rounded-2xl border border-gray-200 object-contain" />
            <div className="mt-1 text-xs text-[#00A844]">✔ {info} (saves storage)</div>
          </div>
        )}
        {(img || text) && (
          <>
            <div>
              <div className="mb-1 text-sm font-semibold">Extracted text</div>
              <textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} placeholder="Text from OCR appears here. You can also type or paste it." className="w-full rounded-2xl border border-gray-200 p-3 text-sm outline-none focus:border-[#6B4EFF]" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {([['sum', 'Summarize', 'sparkles', '#6B4EFF'], ['explain', 'Explain (বাংলা)', 'book', '#FFB300'], ['en', '→ English', 'globe', '#2979FF'], ['bn', '→ বাংলা', 'globe', '#00C853']] as const).map(([k, l, ic, c]) => (
                <button key={k} onClick={() => run(k)} className="flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white active:opacity-80" style={{ background: c }}>
                  <Icon name={ic} size={16} /> {l}
                </button>
              ))}
            </div>
          </>
        )}
        {result && <div className="whitespace-pre-wrap rounded-2xl border-l-4 border-[#6B4EFF] bg-[#EFEBFF] p-4 text-sm leading-relaxed">{result}</div>}
      </div>
      {busy && (
        <div className="absolute inset-0 z-[70] flex items-center justify-center bg-white/70">
          <div className="flex items-center gap-3 rounded-2xl bg-white px-5 py-3 shadow-xl">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-[#6B4EFF] border-t-transparent" />
            <span className="text-sm font-medium">{busy}</span>
          </div>
        </div>
      )}
    </div>
  );
}
