import { useEffect, useRef, useState } from 'react';
import type { Nav } from '../nav';
import { actions, useStore } from '../store';
import { IconBtn, TopBar, toast } from '../ui';

const COLORS = ['#1C1B29', '#6B4EFF', '#00C853', '#2979FF', '#FFD600', '#E53935'];

export default function Draw({ nav }: { nav: Nav }) {
  const { notebooks } = useStore();
  const wrap = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const last = useRef({ x: 0, y: 0 });
  const history = useRef<ImageData[]>([]);
  const [color, setColor] = useState(COLORS[1]);
  const [size, setSize] = useState(4);
  const [eraser, setEraser] = useState(false);

  useEffect(() => {
    const c = cv.current!;
    const w = wrap.current!;
    c.width = w.clientWidth;
    c.height = w.clientHeight;
    const ctx = c.getContext('2d')!;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    return () => {
      history.current = [];
    };
  }, []);

  const pos = (e: React.PointerEvent) => {
    const r = cv.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const down = (e: React.PointerEvent) => {
    const c = cv.current!;
    c.setPointerCapture(e.pointerId);
    const ctx = c.getContext('2d')!;
    history.current.push(ctx.getImageData(0, 0, c.width, c.height));
    if (history.current.length > 8) history.current.shift(); // cap memory
    drawing.current = true;
    last.current = pos(e);
    ctx.beginPath();
    ctx.fillStyle = eraser ? '#fff' : color;
    ctx.arc(last.current.x, last.current.y, (eraser ? size * 3 : size) / 2, 0, Math.PI * 2);
    ctx.fill();
  };
  const move = (e: React.PointerEvent) => {
    if (!drawing.current) return;
    const ctx = cv.current!.getContext('2d')!;
    const p = pos(e);
    ctx.strokeStyle = eraser ? '#fff' : color;
    ctx.lineWidth = eraser ? size * 3 : size;
    ctx.beginPath();
    ctx.moveTo(last.current.x, last.current.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
  };
  const up = () => (drawing.current = false);

  const undo = () => {
    const img = history.current.pop();
    if (img) cv.current!.getContext('2d')!.putImageData(img, 0, 0);
  };
  const clear = () => {
    const c = cv.current!;
    const ctx = c.getContext('2d')!;
    history.current.push(ctx.getImageData(0, 0, c.width, c.height));
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
  };
  const save = () => {
    const nb = notebooks.find((n) => !n.closed) ?? notebooks[0];
    if (!nb) return toast('Create a notebook first');
    const url = cv.current!.toDataURL('image/jpeg', 0.6); // compressed
    const id = actions.addNote(nb.id, 'Handwritten note', `<div><img src="${url}" alt="drawing"></div><div><br></div>`, 'blue');
    toast('Saved as a new page');
    nav.replace({ name: 'editor', id });
  };

  return (
    <div className="flex h-full flex-col bg-white">
      <TopBar
        title="Draw & handwrite"
        onBack={nav.back}
        right={
          <>
            <IconBtn icon="undo" label="Undo" onClick={undo} />
            <IconBtn icon="trash" label="Clear" onClick={clear} />
            <button onClick={save} className="ml-1 rounded-full bg-[#6B4EFF] px-4 py-2 text-sm font-semibold text-white">Save</button>
          </>
        }
      />
      <div ref={wrap} className="relative m-3 min-h-0 flex-1 overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-inner">
        <canvas ref={cv} className="absolute inset-0 touch-none" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} />
      </div>
      <div className="flex shrink-0 items-center gap-3 border-t border-gray-100 px-4 py-3">
        <div className="flex gap-2">
          {COLORS.map((c) => (
            <button
              key={c}
              aria-label={`Color ${c}`}
              onClick={() => {
                setColor(c);
                setEraser(false);
              }}
              className="h-8 w-8 rounded-full border-2 border-white shadow ring-2"
              style={{ background: c, ['--tw-ring-color' as string]: !eraser && color === c ? '#6B4EFF' : 'transparent' }}
            />
          ))}
        </div>
        <input type="range" min={2} max={16} value={size} onChange={(e) => setSize(+e.target.value)} className="min-w-0 flex-1 accent-[#6B4EFF]" aria-label="Brush size" />
        <button onClick={() => setEraser(!eraser)} className={`rounded-full px-3 py-1.5 text-xs font-semibold ${eraser ? 'bg-[#6B4EFF] text-white' : 'bg-gray-100 text-gray-700'}`}>Eraser</button>
      </div>
    </div>
  );
}
