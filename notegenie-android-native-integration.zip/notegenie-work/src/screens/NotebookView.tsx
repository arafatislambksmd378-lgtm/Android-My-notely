import { useState } from 'react';
import { Icon } from '../icons';
import type { Nav } from '../nav';
import { actions, useStore } from '../store';
import { ConfirmDialog, IconBtn, PromptDialog, TopBar, toast } from '../ui';
import { NoteCard } from './Home';

export function NotebookView({ id, nav }: { id: string; nav: Nav }) {
  const { notebooks, notes } = useStore();
  const nb = notebooks.find((n) => n.id === id);
  const [limit, setLimit] = useState(10);
  const [rename, setRename] = useState(false);
  const [del, setDel] = useState(false);
  if (!nb) return <TopBar title="Notebook not found" onBack={nav.back} />;
  const list = notes.filter((n) => n.notebookId === id).sort((a, b) => b.updatedAt - a.updatedAt);

  return (
    <div className="relative flex h-full flex-col bg-white">
      <TopBar
        title={nb.name}
        onBack={nav.back}
        right={
          <>
            <IconBtn icon="edit" label="Rename" onClick={() => setRename(true)} />
            <IconBtn icon="trash" label="Delete" onClick={() => setDel(true)} />
          </>
        }
      />
      <div className="min-h-0 flex-1 overflow-y-auto p-4 pb-28">
        {list.length === 0 ? (
          <div className="py-20 text-center text-gray-500">
            <div className="text-4xl">📒</div>
            <p className="mt-2 text-sm">This notebook is empty.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {list.slice(0, limit).map((n) => (
              <NoteCard key={n.id} note={n} nb={nb} onClick={() => nav.go({ name: 'editor', id: n.id })} />
            ))}
          </div>
        )}
        {limit < list.length && (
          <button onClick={() => setLimit(limit + 10)} className="mx-auto mt-4 block rounded-full bg-gray-100 px-5 py-2 text-sm font-semibold text-gray-700">
            Load more
          </button>
        )}
      </div>
      <button
        onClick={() => nav.go({ name: 'editor', id: actions.addNote(id) })}
        className="absolute bottom-6 right-4 flex items-center gap-2 rounded-full bg-[#6B4EFF] px-5 py-3.5 text-sm font-semibold text-white shadow-xl shadow-[#6B4EFF]/40 active:scale-95"
      >
        <Icon name="plus" size={18} /> Page
      </button>
      {rename && <PromptDialog title="Rename notebook" initial={nb.name} onSubmit={(v) => actions.renameNotebook(id, v)} onClose={() => setRename(false)} />}
      {del && (
        <ConfirmDialog
          title={`Delete “${nb.name}”?`}
          body="All pages inside will be permanently deleted."
          onYes={() => {
            actions.deleteNotebook(id);
            toast('Notebook deleted');
            nav.back();
          }}
          onClose={() => setDel(false)}
        />
      )}
    </div>
  );
}

export function SearchView({ nav }: { nav: Nav }) {
  const { notes, notebooks } = useStore();
  const [q, setQ] = useState('');
  const query = q.trim().toLowerCase();
  const results = query
    ? notes
        .filter((n) => (n.title + ' ' + n.html.replace(/<[^>]+>/g, ' ')).toLowerCase().includes(query))
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .slice(0, 30)
    : [];
  return (
    <div className="flex h-full flex-col bg-white">
      <div className="flex shrink-0 items-center gap-2 border-b border-gray-100 px-2 py-2.5">
        <IconBtn icon="back" onClick={nav.back} label="Back" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search notes…"
          className="min-w-0 flex-1 rounded-full bg-gray-100 px-4 py-2.5 text-[15px] outline-none focus:ring-2 focus:ring-[#6B4EFF]/40"
        />
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {!query ? (
          <p className="py-16 text-center text-sm text-gray-500">Search titles and content across all notebooks.</p>
        ) : results.length === 0 ? (
          <p className="py-16 text-center text-sm text-gray-500">No results for “{q}”.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {results.map((n) => (
              <NoteCard key={n.id} note={n} nb={notebooks.find((b) => b.id === n.notebookId)} onClick={() => nav.go({ name: 'editor', id: n.id })} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
