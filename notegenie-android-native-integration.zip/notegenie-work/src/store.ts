import { isNative, Native } from './native';
import { useSyncExternalStore } from 'react';

export type Tint = 'white' | 'yellow' | 'green' | 'purple' | 'blue';
export type Notebook = { id: string; name: string; color: string; closed: boolean };
export type Note = {
  id: string;
  notebookId: string;
  title: string;
  html: string;
  tint: Tint;
  updatedAt: number;
};
export type Model = {
  id: string;
  name: string;
  file: string;
  quant: string;
  sizeMb: number;
  ramMb: number;
  status: 'available' | 'downloading' | 'installed';
  progress: number;
  imported?: boolean;
};
export type DocData = { title: string; rows: string[][] };
export type ChatMsg = { id: string; role: 'user' | 'ai'; text: string; doc?: DocData };

type State = {
  profile: { name: string };
  notebooks: Notebook[];
  notes: Note[];
  models: Model[];
  activeModelId: string;
  settings: { ctx: number; threads: number };
  chat: ChatMsg[];
};

export const uid = () =>
  (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));

const KEY = 'notegenie.v1';
const day = 86400000;

export const NB_COLORS = ['#6B4EFF', '#00C853', '#2979FF', '#FFB300', '#FF5C8A', '#00B8D4'];

function seed(): State {
  const now = Date.now();
  const nb = (name: string, color: string, closed = false): Notebook => ({ id: uid(), name, color, closed });
  const my = nb('My Notebook', '#6B4EFF');
  const travel = nb('Travel Journal', '#00C853');
  const work = nb('Work Notebook', '#2979FF');
  const closed = [
    nb('School', '#FFB300', true),
    nb('Class work', '#FF5C8A', true),
    nb('Maths', '#2979FF', true),
    nb('Science', '#00C853', true),
    nb('English', '#6B4EFF', true),
  ];
  const note = (nbk: Notebook, title: string, html: string, tint: Tint, ago: number): Note => ({
    id: uid(),
    notebookId: nbk.id,
    title,
    html,
    tint,
    updatedAt: now - ago,
  });
  const notes: Note[] = [
    note(my, 'স্বাগতম NoteGenie AI-তে', '<h2>আপনার অফলাইন AI নোট সহকারী</h2><div>সব নোট আপনার ডিভাইসেই থাকে। কোনো ক্লাউড নেই, কোনো ইন্টারনেট লাগবে না।</div><ul><li>বাংলায় কথা বলে নোট লিখুন</li><li>ছবি স্ক্যান করে সারসংক্ষেপ পান</li><li>PDF, DOCX, Excel এক্সপোর্ট করুন</li></ul>', 'purple', 1000 * 60 * 5),
    note(work, 'Weekly Sprint Plan', '<h2>Sprint 14</h2><div class="chk"><input type="checkbox" checked="">Design review with team</div><div class="chk"><input type="checkbox">Finish API integration</div><div class="chk"><input type="checkbox">Prepare demo for Friday</div>', 'yellow', 1000 * 60 * 60 * 2),
    note(travel, 'কক্সবাজার ভ্রমণ', '<div>সমুদ্রসৈকতে সূর্যাস্ত দেখা, ইনানী বিচ, হিমছড়ি ঝর্ণা এবং স্থানীয় সামুদ্রিক খাবার চেখে দেখা।</div><ul><li>বাস টিকিট কাটতে হবে</li><li>হোটেল বুকিং নিশ্চিত করা</li></ul>', 'green', day),
    note(my, 'Book ideas', '<div>A story about a village librarian who discovers that every book whispers at midnight. Maybe a children’s fantasy series with 3 volumes.</div>', 'blue', day * 2),
    note(work, 'Meeting notes – Product', '<h2>Product sync</h2><div>Launch moved to next month. Focus on offline-first performance for low-end devices. Target: under 1.5GB RAM with 4-bit models.</div>', 'white', day * 3),
    note(travel, 'Packing list', '<div class="chk"><input type="checkbox" checked="">Passport</div><div class="chk"><input type="checkbox">Power bank</div><div class="chk"><input type="checkbox">Rain jacket</div>', 'yellow', day * 4),
    note(closed[2], 'Algebra formulas', '<h2>Algebra</h2><div>(a+b)² = a² + 2ab + b²</div><div>(a−b)² = a² − 2ab + b²</div><div>a² − b² = (a+b)(a−b)</div>', 'purple', day * 6),
    note(closed[3], 'Photosynthesis', '<div>সালোকসংশ্লেষণ হলো এমন প্রক্রিয়া যেখানে সবুজ উদ্ভিদ সূর্যালোকের সাহায্যে কার্বন ডাই-অক্সাইড ও পানি থেকে খাদ্য তৈরি করে এবং অক্সিজেন ছাড়ে।</div>', 'green', day * 7),
    note(closed[4], 'Grammar – Tenses', '<div>Present, Past and Future tense each have four forms: simple, continuous, perfect and perfect continuous.</div>', 'blue', day * 9),
    note(my, 'দৈনিক বাজার তালিকা', '<div class="chk"><input type="checkbox">চাল ২ কেজি</div><div class="chk"><input type="checkbox">ডাল ১ কেজি</div><div class="chk"><input type="checkbox">সবজি</div>', 'yellow', day * 10),
  ];
  const models: Model[] = [
    { id: 'qwen25-15b', name: 'Qwen2.5-1.5B-Instruct', file: 'qwen2.5-1.5b-instruct-q4_k_m.gguf', quant: 'Q4_K_M', sizeMb: 1100, ramMb: 1350, status: 'available', progress: 0 },
    { id: 'qwen25-05b', name: 'Qwen2.5-0.5B-Instruct', file: 'qwen2.5-0.5b-instruct-q4_k_m.gguf', quant: 'Q4_K_M', sizeMb: 400, ramMb: 650, status: 'available', progress: 0 },
    { id: 'llama32-1b', name: 'Llama-3.2-1B-Instruct', file: 'llama-3.2-1b-instruct-q4_k_m.gguf', quant: 'Q4_K_M', sizeMb: 810, ramMb: 1100, status: 'available', progress: 0 },
    { id: 'gemma2-2b', name: 'Gemma-2-2B-it', file: 'gemma-2-2b-it-q4_k_m.gguf', quant: 'Q4_K_M', sizeMb: 1600, ramMb: 2000, status: 'available', progress: 0 },
    { id: 'phi3-mini', name: 'Phi-3-Mini-4K-Instruct', file: 'Phi-3-mini-4k-instruct-q4.gguf', quant: 'Q4_0', sizeMb: 2200, ramMb: 2700, status: 'available', progress: 0 },
  ];
  return {
    profile: { name: 'You' },
    notebooks: [my, travel, work, ...closed],
    notes,
    models,
    activeModelId: '',
    settings: { ctx: 2048, threads: 2 },
    chat: [],
  };
}

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as State;
  } catch {
    /* ignore */
  }
  return seed();
}

let state: State = load();
const subs = new Set<() => void>();
if (isNative) {
  Native.loadSnapshot().then(({ json }) => { if (json) { try { state = JSON.parse(json) as State; } catch { /* retain safe seed */ } } subs.forEach((f) => f()); }).catch(() => undefined);
}
let saveTimer: ReturnType<typeof setTimeout> | undefined;

function commit(fn: (s: State) => State) {
  state = fn(state);
  subs.forEach((f) => f());
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const snapshot = JSON.stringify(state);
    if (isNative) Native.saveSnapshot({ json: snapshot }).catch((e) => console.error('SQLite save failed', e));
    else { try { localStorage.setItem(KEY, snapshot); } catch { /* storage full */ } }
  }, 250);
}

export const useStore = () =>
  useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => {
        subs.delete(cb);
      };
    },
    () => state,
  );

export const getState = () => state;

/* ---------- helpers ---------- */
export function stripHtml(html: string) {
  return html
    .replace(/<img[^>]*>/g, ' [image] ')
    .replace(/<input[^>]*checked[^>]*>/g, '☑ ')
    .replace(/<input[^>]*>/g, '☐ ')
    .replace(/<\/(div|p|li|h1|h2|h3)>|<br\s*\/?>/g, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

export function fmtDate(ts: number) {
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

/* ---------- actions ---------- */
export const actions = {
  addNote(notebookId: string, title = '', html = '', tint?: Tint): string {
    const tints: Tint[] = ['yellow', 'green', 'purple', 'blue', 'white'];
    const id = uid();
    const note: Note = { id, notebookId, title, html, tint: tint ?? tints[Math.floor(Math.random() * 4)], updatedAt: Date.now() };
    commit((s) => ({ ...s, notes: [note, ...s.notes] }));
    return id;
  },
  updateNote(id: string, patch: Partial<Note>) {
    commit((s) => ({ ...s, notes: s.notes.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n)) }));
  },
  deleteNote(id: string) {
    commit((s) => ({ ...s, notes: s.notes.filter((n) => n.id !== id) }));
  },
  moveNote(id: string, notebookId: string) {
    commit((s) => ({ ...s, notes: s.notes.map((n) => (n.id === id ? { ...n, notebookId } : n)) }));
  },
  addNotebook(name: string, closed = false): string {
    const id = uid();
    const color = NB_COLORS[state.notebooks.length % NB_COLORS.length];
    commit((s) => ({ ...s, notebooks: [...s.notebooks, { id, name, color, closed }] }));
    return id;
  },
  renameNotebook(id: string, name: string) {
    commit((s) => ({ ...s, notebooks: s.notebooks.map((n) => (n.id === id ? { ...n, name } : n)) }));
  },
  toggleClosed(id: string) {
    commit((s) => ({ ...s, notebooks: s.notebooks.map((n) => (n.id === id ? { ...n, closed: !n.closed } : n)) }));
  },
  deleteNotebook(id: string) {
    commit((s) => ({
      ...s,
      notebooks: s.notebooks.filter((n) => n.id !== id),
      notes: s.notes.filter((n) => n.notebookId !== id),
    }));
  },
  setProfileName(name: string) {
    commit((s) => ({ ...s, profile: { name } }));
  },
  pushChat(m: ChatMsg) {
    commit((s) => ({ ...s, chat: [...s.chat, m].slice(-40) }));
  },
  clearChat() {
    commit((s) => ({ ...s, chat: [] }));
  },
  setSettings(p: Partial<State['settings']>) {
    commit((s) => ({ ...s, settings: { ...s.settings, ...p, ctx: Math.min(2048, p.ctx ?? s.settings.ctx) } }));
  },
  setActiveModel(id: string) {
    commit((s) => ({ ...s, activeModelId: id }));
  },
  patchModel(id: string, p: Partial<Model>) {
    commit((s) => ({ ...s, models: s.models.map((m) => (m.id === id ? { ...m, ...p } : m)) }));
  },
  importModel(file: File | { name: string; size: number; path: string }) {
    const sizeMb = Math.round(file.size / 1048576);
    const m: Model = {
      id: uid(),
      name: file.name.replace(/\.gguf$/i, ''),
      file: 'path' in file ? file.path : file.name,
      quant: (file.name.match(/q\d_[a-z0-9_]+/i)?.[0] ?? 'GGUF').toUpperCase(),
      sizeMb,
      ramMb: Math.round(sizeMb * 1.2),
      status: 'installed',
      progress: 100,
      imported: true,
    };
    commit((s) => ({ ...s, models: [...s.models, m], activeModelId: m.id }));
  },
  removeModel(id: string) {
    commit((s) => {
      const target = s.models.find((m) => m.id === id);
      const models = target?.imported
        ? s.models.filter((m) => m.id !== id)
        : s.models.map((m) => (m.id === id ? { ...m, status: 'available' as const, progress: 0 } : m));
      const active = s.activeModelId === id ? (models.find((m) => m.status === 'installed')?.id ?? '') : s.activeModelId;
      return { ...s, models, activeModelId: active };
    });
  },
  downloadModel(_id: string) {
    // Model binaries are never faked. Users must import a real GGUF through Android SAF.
  },
  resetAll() {
    localStorage.removeItem(KEY);
    commit(() => seed());
  },
};
