import { isNative, Native } from './native';
import { useCallback, useEffect, useRef, useState } from 'react';

/* eslint-disable @typescript-eslint/no-explicit-any */
const SR: any = typeof window !== 'undefined' ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition : null;

export const sttSupported = isNative || !!SR;

/** Speech-to-text hook (Bengali by default). Native build uses Vosk offline model. */
export function useSTT(onFinal: (text: string) => void, lang = 'bn-BD') {
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  const rec = useRef<any>(null);
  const cb = useRef(onFinal);
  cb.current = onFinal;

  const stop = useCallback(() => {
    if (isNative) Native.stopListening().then((r) => { if (r.text) cb.current(r.text); }).catch(() => undefined);
    else rec.current?.stop();
    setListening(false);
  }, []);

  const start = useCallback(() => {
    if (isNative) {
      setInterim('');
      Native.addListener('speechPartial', (v) => setInterim(v.text ?? ''));
      Native.addListener('speechFinal', (v) => { if (v.text) cb.current(v.text); });
      Native.startListening().then(() => setListening(true)).catch(() => setListening(false));
      return true;
    }
    if (!SR) return false;
    const r = new SR();
    r.lang = lang;
    r.continuous = true;
    r.interimResults = true;
    r.onresult = (e: any) => {
      let it = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) cb.current(t.trim());
        else it += t;
      }
      setInterim(it);
    };
    r.onend = () => {
      setListening(false);
      setInterim('');
    };
    r.onerror = () => {
      setListening(false);
      setInterim('');
    };
    rec.current = r;
    try {
      r.start();
      setListening(true);
      return true;
    } catch {
      return false;
    }
  }, [lang]);

  useEffect(() => () => rec.current?.abort?.(), []);
  return { listening, interim, start, stop };
}

/** Text-to-speech using the platform voice (Android native TTS in the app). */
export function speak(text: string, lang = 'bn-BD') {
  if (isNative) { Native.speak({ text, language: lang }).catch(() => undefined); return true; }
  if (!('speechSynthesis' in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  const bn = /[\u0980-\u09FF]/.test(text);
  u.lang = bn ? lang : 'en-US';
  const v = window.speechSynthesis.getVoices().find((x) => x.lang.toLowerCase().startsWith(u.lang.slice(0, 2).toLowerCase()));
  if (v) u.voice = v;
  window.speechSynthesis.speak(u);
  return true;
}
export const stopSpeaking = () => { if (isNative) Native.stopSpeaking().catch(() => undefined); else if ('speechSynthesis' in window) window.speechSynthesis.cancel(); };

/** Downscale + JPEG-compress an image before storing it (saves ROM/RAM). */
export async function compressImage(file: Blob, maxDim = 1280, quality = 0.7): Promise<string> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close?.();
  const url = c.toDataURL('image/jpeg', quality);
  c.width = c.height = 0; // release canvas memory
  return url;
}
