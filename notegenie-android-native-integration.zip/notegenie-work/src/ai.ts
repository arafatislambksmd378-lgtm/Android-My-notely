import { isNative, Native } from './native';
import { getState } from './store';
import type { ChatMsg, DocData } from './store';

/**
 * Local AI engine facade.
 *
 * Android uses the NoteGenie Capacitor plugin and JNI llama.cpp runtime.
 * Browser preview retains a deterministic local demo engine and is not an LLM.
 */

export type Mode = 'chat' | 'translate' | 'summarize' | 'document';
export const MAX_CTX = 2048;

// Bengali script is token-hungry: ~1 token per 1.6 chars; Latin ~ 1 per 4 chars.
export function estimateTokens(text: string) {
  const bn = (text.match(/[\u0980-\u09FF]/g) || []).length;
  return Math.ceil(bn / 1.6 + (text.length - bn) / 4);
}

/** Keep newest messages that fit inside the context budget. */
export function trimHistory(msgs: ChatMsg[], budget: number) {
  const out: ChatMsg[] = [];
  let used = 0;
  for (let i = msgs.length - 1; i >= 0; i--) {
    const t = estimateTokens(msgs[i].text);
    if (used + t > budget) break;
    used += t;
    out.unshift(msgs[i]);
  }
  return { messages: out, tokens: used };
}

const isBn = (t: string) => /[\u0980-\u09FF]/.test(t);
const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((res, rej) => {
    const t = setTimeout(res, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(t);
      rej(new DOMException('aborted', 'AbortError'));
    });
  });

/* ---------------- translation (offline mini lexicon) ---------------- */
const LEX: [string, string][] = [
  ['hello', 'হ্যালো'], ['hi', 'হাই'], ['thank you', 'ধন্যবাদ'], ['thanks', 'ধন্যবাদ'], ['good morning', 'শুভ সকাল'], ['good night', 'শুভ রাত্রি'],
  ['how are you', 'আপনি কেমন আছেন'], ['i am fine', 'আমি ভালো আছি'], ['i', 'আমি'], ['you', 'আপনি'], ['we', 'আমরা'], ['he', 'সে'], ['she', 'সে'], ['they', 'তারা'],
  ['love', 'ভালোবাসি'], ['like', 'পছন্দ করি'], ['want', 'চাই'], ['need', 'দরকার'], ['go', 'যাই'], ['come', 'আসি'], ['eat', 'খাই'], ['read', 'পড়ি'], ['write', 'লিখি'],
  ['book', 'বই'], ['note', 'নোট'], ['notes', 'নোটসমূহ'], ['school', 'স্কুল'], ['teacher', 'শিক্ষক'], ['student', 'শিক্ষার্থী'], ['friend', 'বন্ধু'], ['family', 'পরিবার'],
  ['water', 'পানি'], ['food', 'খাবার'], ['rice', 'ভাত'], ['home', 'বাড়ি'], ['house', 'ঘর'], ['city', 'শহর'], ['village', 'গ্রাম'], ['country', 'দেশ'], ['today', 'আজ'],
  ['tomorrow', 'আগামীকাল'], ['yesterday', 'গতকাল'], ['time', 'সময়'], ['work', 'কাজ'], ['meeting', 'মিটিং'], ['plan', 'পরিকল্পনা'], ['project', 'প্রকল্প'], ['good', 'ভালো'],
  ['bad', 'খারাপ'], ['big', 'বড়'], ['small', 'ছোট'], ['new', 'নতুন'], ['old', 'পুরানো'], ['is', 'হয়'], ['are', 'হন'], ['the', ''], ['a', 'একটি'], ['an', 'একটি'], ['and', 'এবং'],
  ['to', 'কে'], ['in', 'এ'], ['of', 'এর'], ['my', 'আমার'], ['your', 'আপনার'], ['name', 'নাম'], ['what', 'কী'], ['where', 'কোথায়'], ['why', 'কেন'], ['when', 'কখন'], ['how', 'কীভাবে'],
  ['bangladesh', 'বাংলাদেশ'], ['dhaka', 'ঢাকা'], ['yes', 'হ্যাঁ'], ['no', 'না'], ['please', 'দয়া করে'], ['sorry', 'দুঃখিত'], ['help', 'সাহায্য'], ['story', 'গল্প'], ['travel', 'ভ্রমণ'],
];
const EN2BN = new Map(LEX);
const BN2EN = new Map(LEX.filter(([, b]) => b).map(([e, b]) => [b, e] as [string, string]));

export function translate(text: string, to?: 'en' | 'bn') {
  const target = to ?? (isBn(text) ? 'en' : 'bn');
  const src = text.trim();
  let out: string;
  if (target === 'bn') {
    let s = ' ' + src.toLowerCase().replace(/[.!?]+$/, '') + ' ';
    [...EN2BN.entries()].sort((a, b) => b[0].length - a[0].length).forEach(([e, b]) => {
      if (e.includes(' ')) s = s.split(` ${e} `).join(` ${b} `);
    });
    out = s
      .trim()
      .split(/\s+/)
      .map((w) => EN2BN.get(w) ?? w)
      .filter(Boolean)
      .join(' ');
    if (!/[।]$/.test(out)) out += '।';
  } else {
    out = src
      .replace(/[।.!?]+$/, '')
      .split(/\s+/)
      .map((w) => BN2EN.get(w) ?? w)
      .join(' ');
    out = out.charAt(0).toUpperCase() + out.slice(1) + '.';
  }
  return target === 'bn'
    ? `🌐 বাংলা অনুবাদ:\n${out}\n\n(অফলাইন অভিধান-ভিত্তিক অনুবাদ। বড় GGUF মডেল লোড থাকলে আরও নির্ভুল হয়।)`
    : `🌐 English translation:\n${out}\n\n(Offline lexicon-based translation. Load a larger GGUF model for better accuracy.)`;
}

/* ---------------- summarization ---------------- */
const STOP = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'are', 'was', 'from', 'have', 'এবং', 'এই', 'করে', 'হয়', 'যা', 'এর', 'থেকে', 'জন্য', 'তার', 'একটি', 'যে', 'না', 'ও', 'কিন্তু', 'সে']);
export function summarize(text: string, explain = false) {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (clean.length < 20) return 'সারসংক্ষেপ করার জন্য যথেষ্ট লেখা পাওয়া যায়নি। অনুগ্রহ করে আরও কিছু টেক্সট দিন।';
  const sentences = clean.split(/(?<=[।.!?])\s+/).filter((s) => s.length > 8);
  const freq = new Map<string, number>();
  clean
    .toLowerCase()
    .split(/[\s,।.!?;:()"'-]+/)
    .filter((w) => w.length > 2 && !STOP.has(w))
    .forEach((w) => freq.set(w, (freq.get(w) || 0) + 1));
  const scored = sentences.map((s, i) => ({
    s,
    i,
    score: s.toLowerCase().split(/[\s,।.!?;:()"'-]+/).reduce((a, w) => a + (freq.get(w) || 0), 0) / Math.sqrt(s.length) + (i === 0 ? 2 : 0),
  }));
  const top = scored.sort((a, b) => b.score - a.score).slice(0, 3).sort((a, b) => a.i - b.i);
  const keys = [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([w]) => w);
  const points = (top.length ? top.map((t) => t.s) : [clean.slice(0, 160)]).map((s) => `• ${s}`).join('\n');
  if (explain)
    return `📖 ধারণাটি সহজ ভাষায়:\n${points}\n\n🔑 মূল শব্দ: ${keys.join(', ')}\n\n💡 সহজভাবে বলতে গেলে, লেখাটির মূল বিষয় হলো "${keys.slice(0, 2).join(' ও ')}"। একে ছোট ছোট অংশে ভেঙে পড়লে বুঝতে সুবিধা হবে।`;
  return `📝 সারসংক্ষেপ:\n${points}\n\n🔑 মূল শব্দ: ${keys.join(', ')}`;
}

/* ---------------- document generation ---------------- */
export function makeDocument(prompt: string): DocData {
  const p = prompt.toLowerCase();
  if (/budget|expense|বাজেট|খরচ|হিসাব/.test(p))
    return { title: 'Monthly Budget', rows: [['Category', 'Planned (৳)', 'Actual (৳)', 'Difference (৳)'], ['Rent / বাসা ভাড়া', '12000', '12000', '0'], ['Food / খাবার', '8000', '8600', '-600'], ['Transport / যাতায়াত', '2500', '2200', '300'], ['Internet & Mobile', '1200', '1200', '0'], ['Savings / সঞ্চয়', '5000', '4500', '500'], ['Total', '28700', '28500', '200']] };
  if (/attendance|উপস্থিতি/.test(p))
    return { title: 'Attendance Sheet', rows: [['Roll', 'Name', 'Present', 'Absent', 'Percentage'], ['01', 'Rahim', '22', '2', '92%'], ['02', 'Karima', '24', '0', '100%'], ['03', 'Sumon', '20', '4', '83%'], ['04', 'Nusrat', '23', '1', '96%']] };
  if (/mark|result|grade|ফলাফল|নম্বর|রেজাল্ট/.test(p))
    return { title: 'Exam Results', rows: [['Subject', 'Full Marks', 'Obtained', 'Grade'], ['Bangla', '100', '82', 'A+'], ['English', '100', '76', 'A'], ['Mathematics', '100', '91', 'A+'], ['Science', '100', '68', 'A-']] };
  if (/routine|timetable|schedule|রুটিন|সময়সূচী/.test(p))
    return { title: 'Weekly Routine', rows: [['Day', 'Morning', 'Afternoon', 'Evening'], ['Sunday', 'Maths', 'English', 'Revision'], ['Monday', 'Science', 'Bangla', 'Homework'], ['Tuesday', 'English', 'Maths', 'Reading'], ['Wednesday', 'Bangla', 'Science', 'Practice'], ['Thursday', 'Maths', 'ICT', 'Revision']] };
  const topic = prompt.replace(/(তৈরি করো|বানাও|generate|create|make|pdf|excel|table|টেবিল|রিপোর্ট|report)/gi, '').trim().slice(0, 40) || 'Project';
  return { title: `${topic} – Report`, rows: [['Task', 'Owner', 'Status', 'Deadline'], ['Requirement analysis', 'Team A', 'Done', '05 Jan'], ['UI/UX design', 'Team B', 'In progress', '15 Jan'], ['Development', 'Team C', 'Planned', '10 Feb'], ['Testing & QA', 'Team D', 'Planned', '25 Feb'], ['Release', 'All', 'Planned', '01 Mar']] };
}

export const tableToText = (d: DocData) => d.rows.map((r) => r.join(' | ')).join('\n');

/* ---------------- chat intents ---------------- */
function chatReply(prompt: string): string {
  const p = prompt.toLowerCase();
  if (/story|গল্প/.test(p))
    return '📖 একটি ছোট গল্প — "নদীর পাড়ের লাইব্রেরি"\n\nপদ্মা নদীর পাড়ে এক ছোট্ট গ্রামে বাস করতেন বৃদ্ধ লাইব্রেরিয়ান করিম চাচা। প্রতি রাতে তিনি লক্ষ করতেন, বইগুলো ফিসফিস করে কথা বলছে। এক রাতে সাহস করে তিনি একটি পুরোনো বই খুলতেই বেরিয়ে এল এক আলোর নদী — সেই নদী তাঁকে নিয়ে গেল সব হারিয়ে যাওয়া গল্পের দেশে।\n\nসকালে গ্রামের শিশুরা এসে দেখল, লাইব্রেরির প্রতিটি বইয়ে নতুন এক গল্প লেখা। সেদিন থেকে গ্রামের সবাই জানল — গল্পরা কখনো হারায় না, তারা শুধু অপেক্ষা করে।\n\nচাইলে আমি গল্পটি আরও বড় করতে বা নোটে সেভ করতে পারি।';
  if (/architect|আর্কিটেকচার|plan|পরিকল্পনা|design/.test(p))
    return '🏗️ প্রস্তাবিত আর্কিটেকচার:\n\n1. **UI স্তর** — Flutter/React, ৬০fps, lazy list ও pagination\n2. **ডেটা স্তর** — SQLite, ১০টি করে নোট পেজিনেশনে লোড\n3. **AI স্তর** — llama.cpp (4-bit GGUF) আলাদা Isolate/Worker-এ চলবে\n4. **কনটেক্সট** — সর্বোচ্চ ২০৪৮ টোকেন, পুরোনো বার্তা স্বয়ংক্রিয়ভাবে ছাঁটাই\n5. **ফাইল স্তর** — PDF / DOCX / XLSX / TXT এক্সপোর্ট ও শেয়ার\n6. **মিডিয়া** — ছবি সংরক্ষণের আগে কম্প্রেস\n\nআপনি কোন অংশ নিয়ে বিস্তারিত জানতে চান?';
  if (/hello|hi\b|হ্যালো|নমস্কার|সালাম|হাই|কেমন|কি খবর/.test(p))
    return 'আসসালামু আলাইকুম! 👋 আমি NoteGenie AI — আপনার অফলাইন সহকারী। আমি বাংলায় কথা বলতে, নোট লিখতে, সারসংক্ষেপ করতে, অনুবাদ করতে এবং PDF/Excel বানাতে পারি। আজ কীভাবে সাহায্য করতে পারি?';
  if (/who are you|তুমি কে|তোমার নাম/.test(p))
    return 'আমি NoteGenie AI — আপনার ডিভাইসেই চলা একটি লোকাল AI। আপনার কোনো তথ্য ইন্টারনেটে যায় না। 🔒';
  if (/note|নোট|টিপস|tip/.test(p))
    return '📝 ভালো নোট নেওয়ার ৪টি টিপস:\n• শিরোনাম দিয়ে শুরু করুন\n• বড় তথ্য ছোট বুলেটে ভাঙুন\n• করণীয় কাজ চেকলিস্টে রাখুন\n• দিনের শেষে AI দিয়ে সারসংক্ষেপ করুন';
  if (/math|গণিত|হিসাব|\d\s*[+\-*/x×]\s*\d/.test(p)) {
    const m = prompt.match(/(\d+(?:\.\d+)?)\s*([+\-*/x×])\s*(\d+(?:\.\d+)?)/);
    if (m) {
      const a = +m[1], b = +m[3];
      const r = m[2] === '+' ? a + b : m[2] === '-' ? a - b : m[2] === '/' ? (b ? a / b : NaN) : a * b;
      return `🔢 ${a} ${m[2]} ${b} = **${Number.isNaN(r) ? 'অসংজ্ঞায়িত' : +r.toFixed(4)}**`;
    }
  }
  return `আপনার প্রশ্নটি বুঝতে পেরেছি: "${prompt.slice(0, 80)}${prompt.length > 80 ? '…' : ''}"\n\nআমি অফলাইনে চলছি, তাই সংক্ষেপে বলছি — বিষয়টি নিয়ে আরও নির্দিষ্টভাবে জানালে (যেমন: "সারসংক্ষেপ করো", "ইংরেজিতে অনুবাদ করো", "বাজেটের Excel বানাও") আমি আরও ভালো সাহায্য করতে পারব। 😊`;
}

export type Result = { text: string; doc?: DocData };

export function detectMode(prompt: string, mode: Mode): Mode {
  if (mode !== 'chat') return mode;
  const p = prompt.toLowerCase();
  if (/translate|অনুবাদ/.test(p)) return 'translate';
  if (/summar|সারাংশ|সারসংক্ষেপ/.test(p)) return 'summarize';
  if (/(table|টেবিল|excel|এক্সেল|pdf|পিডিএফ|report|রিপোর্ট|রুটিন|routine|বাজেট|budget).*(তৈরি|বানাও|generate|create|make|দাও)|(তৈরি|বানাও|generate|create|make).*(table|টেবিল|excel|এক্সেল|pdf|পিডিএফ|report|রিপোর্ট|রুটিন|routine|বাজেট|budget)/.test(p))
    return 'document';
  return 'chat';
}

export function compute(prompt: string, mode: Mode): Result {
  const m = detectMode(prompt, mode);
  const body = prompt.replace(/^(translate|অনুবাদ করো|অনুবাদ|summarize|সারসংক্ষেপ করো|সারাংশ)\s*[:：-]?\s*/i, '');
  if (m === 'translate') {
    const to = /to english|ইংরেজি/i.test(prompt) ? 'en' : /to bengali|বাংলা/i.test(prompt) ? 'bn' : undefined;
    return { text: translate(body.replace(/(to english|to bengali|ইংরেজিতে|বাংলায়)/gi, '').trim() || body, to) };
  }
  if (m === 'summarize') return { text: summarize(body) };
  if (m === 'document') {
    const doc = makeDocument(prompt);
    return { text: `📄 "${doc.title}" তৈরি হয়েছে। নিচের বাটন থেকে PDF, Excel বা DOCX হিসেবে ডাউনলোড করুন।\n\n${tableToText(doc)}`, doc };
  }
  return { text: chatReply(prompt) };
}

/** Streams tokens like a real on-device model would. Cancelable via AbortSignal. */
export async function generate(
  prompt: string,
  mode: Mode,
  onToken: (partial: string) => void,
  signal?: AbortSignal,
): Promise<Result> {
  if (isNative) {
    const state = getState();
    const model = state.models.find((m) => m.id === state.activeModelId && m.status === 'installed');
    if (!model) throw new Error('Settings থেকে একটি বাস্তব GGUF মডেল import করুন।');
    await Native.loadModel({ path: model.file, context: state.settings.ctx, threads: state.settings.threads });
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const task = mode === 'summarize' ? 'নিচের লেখাটির নির্ভুল সারসংক্ষেপ দাও।' : mode === 'translate' ? 'নিচের লেখাটি যথাযথভাবে অনুবাদ করো।' : mode === 'document' ? 'ব্যবহারকারীর চাহিদা অনুযায়ী ডকুমেন্টের বিষয়বস্তু তৈরি করো।' : 'প্রশ্নের সরাসরি উত্তর দাও।';
    const result = await Native.generate({ prompt: `তুমি NoteGenie AI, একজন সহায়ক বাংলা AI assistant। ${task} প্রশ্নের ভাষা অনুসারে উত্তর দাও।\n\nব্যবহারকারী: ${prompt}\nসহকারী:`, maxTokens: 384, temperature: 0.7 });
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    for (let i = 0; i < result.text.length; i += 3) { onToken(result.text.slice(0, i + 3)); }
    return { text: result.text.trim() };
  }
  await sleep(450, signal); // web preview only; not an on-device LLM
  const res = compute(prompt, mode);
  let i = 0;
  while (i < res.text.length) {
    i = Math.min(res.text.length, i + 3);
    onToken(res.text.slice(0, i));
    await sleep(14, signal);
  }
  return res;
}
