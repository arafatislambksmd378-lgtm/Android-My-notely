import type { DocData } from './store';

export type Fmt = 'txt' | 'pdf' | 'docx' | 'xlsx';

export function htmlToText(html: string) {
  const s = html
    .replace(/<input[^>]*checked[^>]*>/g, '☑ ')
    .replace(/<input[^>]*>/g, '☐ ')
    .replace(/<li[^>]*>/g, '• ')
    .replace(/<img[^>]*>/g, '[image]')
    .replace(/<\/(div|p|li|h1|h2|h3|ul|ol)>|<br\s*\/?>/g, '\n');
  const d = document.createElement('div');
  d.innerHTML = s;
  return (d.textContent || '').replace(/\u200b/g, '').replace(/\n{3,}/g, '\n\n').trim();
}

const MIME: Record<Fmt, string> = {
  txt: 'text/plain;charset=utf-8',
  pdf: 'application/pdf',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
};

const safe = (n: string) => (n.trim() || 'note').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 60);

/** Opens the Android-style share sheet when available, else downloads. */
async function deliver(blob: Blob, name: string, share: boolean): Promise<'shared' | 'saved'> {
  const file = new File([blob], name, { type: blob.type });
  const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
  if (share && nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: name });
      return 'shared';
    } catch (e) {
      if ((e as DOMException).name === 'AbortError') return 'shared';
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return 'saved';
}

function printPdf(title: string, bodyHtml: string) {
  const f = document.createElement('iframe');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(f);
  const doc = f.contentDocument!;
  doc.open();
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>body{font-family:'Noto Sans Bengali','Inter',Arial,sans-serif;padding:28px;line-height:1.6;color:#1c1b29}
  h1{color:#6B4EFF}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:6px 10px;text-align:left}
  th{background:#6B4EFF;color:#fff}img{max-width:100%}.chk input{margin-right:6px}</style></head><body>${bodyHtml}</body></html>`);
  doc.close();
  setTimeout(() => {
    f.contentWindow?.focus();
    f.contentWindow?.print();
    setTimeout(() => f.remove(), 2000);
  }, 400);
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');

async function buildDocx(title: string, html: string | null, rows?: string[][]) {
  const D = await import('docx');
  const font = 'Nirmala UI';
  const kids: (InstanceType<typeof D.Paragraph> | InstanceType<typeof D.Table>)[] = [
    new D.Paragraph({ heading: D.HeadingLevel.TITLE, children: [new D.TextRun({ text: title || 'Untitled', font })] }),
  ];
  if (rows) {
    kids.push(
      new D.Table({
        width: { size: 100, type: D.WidthType.PERCENTAGE },
        rows: rows.map(
          (r, i) =>
            new D.TableRow({
              children: r.map(
                (c) => new D.TableCell({ children: [new D.Paragraph({ children: [new D.TextRun({ text: c, bold: i === 0, font })] })] }),
              ),
            }),
        ),
      }),
    );
  }
  if (html) {
    const root = new DOMParser().parseFromString(`<body>${html}</body>`, 'text/html').body;
    const runs = (n: Node, f: { b?: boolean; i?: boolean; u?: boolean } = {}): InstanceType<typeof D.TextRun>[] => {
      if (n.nodeType === 3) {
        const t = (n.textContent || '').replace(/\u200b/g, '');
        return t ? [new D.TextRun({ text: t, bold: f.b, italics: f.i, underline: f.u ? {} : undefined, font })] : [];
      }
      if (n.nodeType !== 1) return [];
      const el = n as HTMLElement;
      const tag = el.tagName.toLowerCase();
      if (tag === 'input') return [new D.TextRun({ text: (el as HTMLInputElement).hasAttribute('checked') ? '☑ ' : '☐ ', font })];
      if (tag === 'img') return [];
      const nf = { b: f.b || tag === 'b' || tag === 'strong', i: f.i || tag === 'i' || tag === 'em', u: f.u || tag === 'u' };
      return [...el.childNodes].flatMap((c) => runs(c, nf));
    };
    root.childNodes.forEach((n) => {
      if (n.nodeType === 3) {
        if (n.textContent?.trim()) kids.push(new D.Paragraph({ children: runs(n) }));
        return;
      }
      const el = n as HTMLElement;
      const tag = el.tagName?.toLowerCase();
      if (tag === 'h1') kids.push(new D.Paragraph({ heading: D.HeadingLevel.HEADING_1, children: runs(el) }));
      else if (tag === 'h2' || tag === 'h3') kids.push(new D.Paragraph({ heading: D.HeadingLevel.HEADING_2, children: runs(el) }));
      else if (tag === 'ul' || tag === 'ol')
        el.querySelectorAll('li').forEach((li) => kids.push(new D.Paragraph({ bullet: { level: 0 }, children: runs(li) })));
      else if (tag !== 'img') kids.push(new D.Paragraph({ children: runs(el) }));
    });
  }
  return D.Packer.toBlob(new D.Document({ sections: [{ children: kids }] }));
}

async function buildXlsx(sheetName: string, rows: string[][]) {
  const X = await import('xlsx');
  const ws = X.utils.aoa_to_sheet(rows.map((r) => r.map((c) => (c !== '' && !isNaN(Number(c)) ? Number(c) : c))));
  ws['!cols'] = rows[0].map((_, i) => ({ wch: Math.min(40, Math.max(10, ...rows.map((r) => (r[i] || '').length + 2))) }));
  const wb = X.utils.book_new();
  X.utils.book_append_sheet(wb, ws, sheetName.slice(0, 28) || 'Sheet1');
  const out = X.write(wb, { type: 'array', bookType: 'xlsx' });
  return new Blob([out], { type: MIME.xlsx });
}

function noteRows(html: string): string[][] {
  const lines = htmlToText(html).split('\n').filter((l) => l.trim());
  const rows = lines.map((l) => {
    const m = l.match(/^([☑☐])\s*(.*)$/);
    return m ? [m[1] === '☑' ? 'Done' : 'Pending', m[2]] : ['', l.replace(/^•\s*/, '')];
  });
  return [['Status', 'Text'], ...rows];
}

export async function exportNote(title: string, html: string, fmt: Fmt, share = false) {
  const name = `${safe(title)}.${fmt}`;
  if (fmt === 'pdf') {
    printPdf(title, `<h1>${esc(title || 'Untitled')}</h1>${html}`);
    return 'pdf';
  }
  let blob: Blob;
  if (fmt === 'txt') blob = new Blob([`${title}\n\n${htmlToText(html)}`], { type: MIME.txt });
  else if (fmt === 'docx') blob = await buildDocx(title, html);
  else blob = await buildXlsx(title || 'Note', noteRows(html));
  return deliver(blob, name, share);
}

export async function exportTable(doc: DocData, fmt: Fmt, share = false) {
  const name = `${safe(doc.title)}.${fmt}`;
  if (fmt === 'pdf') {
    const [h, ...b] = doc.rows;
    printPdf(
      doc.title,
      `<h1>${esc(doc.title)}</h1><table><tr>${h.map((c) => `<th>${esc(c)}</th>`).join('')}</tr>${b
        .map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`)
        .join('')}</table>`,
    );
    return 'pdf';
  }
  let blob: Blob;
  if (fmt === 'txt') blob = new Blob([`${doc.title}\n\n${doc.rows.map((r) => r.join('\t')).join('\n')}`], { type: MIME.txt });
  else if (fmt === 'docx') blob = await buildDocx(doc.title, null, doc.rows);
  else blob = await buildXlsx(doc.title, doc.rows);
  return deliver(blob, name, share);
}

export async function exportText(title: string, text: string, fmt: Fmt, share = false) {
  return exportNote(title, text.split('\n').map((l) => `<div>${esc(l)}</div>`).join(''), fmt, share);
}
