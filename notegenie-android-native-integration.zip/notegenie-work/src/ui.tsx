import { useEffect, useState, type ReactNode } from 'react';
import { Icon } from './icons';

/* ---------- toast ---------- */
let toastFn: (m: string) => void = () => {};
export const toast = (m: string) => toastFn(m);
export function ToastHost() {
  const [msg, setMsg] = useState('');
  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;
    toastFn = (m) => {
      setMsg(m);
      clearTimeout(t);
      t = setTimeout(() => setMsg(''), 2400);
    };
  }, []);
  if (!msg) return null;
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-28 z-[100] flex justify-center px-6">
      <div className="sheet-anim rounded-full bg-[#1c1b29] px-4 py-2 text-sm font-medium text-white shadow-lg">{msg}</div>
    </div>
  );
}

/* ---------- bottom sheet ---------- */
export function Sheet({ title, onClose, children }: { title?: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-50 flex items-end bg-black/40" onClick={onClose}>
      <div className="sheet-anim max-h-[85%] w-full overflow-y-auto rounded-t-3xl bg-white p-4 pb-6" onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-gray-300" />
        {title && <div className="mb-2 px-1 text-base font-semibold">{title}</div>}
        {children}
      </div>
    </div>
  );
}

export function SheetItem({
  icon,
  label,
  sub,
  color = '#6B4EFF',
  danger,
  onClick,
  right,
}: {
  icon: string;
  label: string;
  sub?: string;
  color?: string;
  danger?: boolean;
  onClick?: () => void;
  right?: ReactNode;
}) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 rounded-2xl px-2 py-2.5 text-left active:bg-gray-100">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl" style={{ background: (danger ? '#E53935' : color) + '1A', color: danger ? '#E53935' : color }}>
        <Icon name={icon} size={20} />
      </span>
      <span className="min-w-0 flex-1">
        <span className={`block text-[15px] font-medium ${danger ? 'text-red-600' : ''}`}>{label}</span>
        {sub && <span className="block truncate text-xs text-gray-500">{sub}</span>}
      </span>
      {right}
    </button>
  );
}

/* ---------- prompt dialog ---------- */
export function PromptDialog({
  title,
  initial = '',
  confirm = 'Save',
  onSubmit,
  onClose,
}: {
  title: string;
  initial?: string;
  confirm?: string;
  onSubmit: (v: string) => void;
  onClose: () => void;
}) {
  const [v, setV] = useState(initial);
  const go = () => {
    if (v.trim()) {
      onSubmit(v.trim());
      onClose();
    }
  };
  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/40 p-6" onClick={onClose}>
      <div className="sheet-anim w-full rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 text-lg font-semibold">{title}</div>
        <input
          autoFocus
          value={v}
          onChange={(e) => setV(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && go()}
          className="w-full rounded-xl border border-gray-200 px-3 py-2.5 outline-none focus:border-[#6B4EFF]"
        />
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-full px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
          <button onClick={go} className="rounded-full bg-[#6B4EFF] px-5 py-2 text-sm font-semibold text-white">{confirm}</button>
        </div>
      </div>
    </div>
  );
}

export function ConfirmDialog({ title, body, confirm = 'Delete', onYes, onClose }: { title: string; body: string; confirm?: string; onYes: () => void; onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/40 p-6" onClick={onClose}>
      <div className="sheet-anim w-full rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
        <div className="text-lg font-semibold">{title}</div>
        <p className="mt-1 text-sm text-gray-600">{body}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-full px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
          <button
            onClick={() => {
              onYes();
              onClose();
            }}
            className="rounded-full bg-red-600 px-5 py-2 text-sm font-semibold text-white"
          >
            {confirm}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- misc ---------- */
export function Avatar({ name, size = 40, onClick }: { name: string; size?: number; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{ width: size, height: size, background: 'linear-gradient(135deg,#6B4EFF,#2979FF)' }}
      className="flex shrink-0 items-center justify-center rounded-full text-sm font-bold text-white ring-2 ring-[#EFEBFF]"
    >
      {name.trim().charAt(0).toUpperCase() || 'U'}
    </button>
  );
}

export function TopBar({ title, onBack, right }: { title: ReactNode; onBack: () => void; right?: ReactNode }) {
  return (
    <div className="flex shrink-0 items-center gap-1 border-b border-gray-100 bg-white px-2 py-2.5">
      <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full text-gray-700 active:bg-gray-100" aria-label="Back">
        <Icon name="back" />
      </button>
      <div className="min-w-0 flex-1 truncate text-[17px] font-semibold">{title}</div>
      {right}
    </div>
  );
}

export const IconBtn = ({ icon, onClick, active, label, color }: { icon: string; onClick?: () => void; active?: boolean; label?: string; color?: string }) => (
  <button
    aria-label={label}
    onMouseDown={(e) => e.preventDefault()}
    onClick={onClick}
    style={color ? { color } : undefined}
    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full active:bg-gray-100 ${active ? 'bg-[#EFEBFF] text-[#6B4EFF]' : 'text-gray-700'}`}
  >
    <Icon name={icon} size={21} />
  </button>
);

export const TINTS: Record<string, { bg: string; border: string }> = {
  white: { bg: '#FFFFFF', border: '#ECEAF5' },
  yellow: { bg: '#FFF8D6', border: '#FFEE99' },
  green: { bg: '#E3F8EA', border: '#B7EBC8' },
  purple: { bg: '#EFEBFF', border: '#D5CBFF' },
  blue: { bg: '#E6F0FF', border: '#BDD6FF' },
};
