import { useCallback, useMemo, useState } from 'react';
import type { Nav, Route } from './nav';
import Chat from './screens/Chat';
import Draw from './screens/Draw';
import Editor from './screens/Editor';
import Home from './screens/Home';
import { NotebookView, SearchView } from './screens/NotebookView';
import Scan from './screens/Scan';
import Settings from './screens/Settings';
import Voice from './screens/Voice';
import { ToastHost } from './ui';

export default function App() {
  const [stack, setStack] = useState<Route[]>([{ name: 'home' }]);
  const [tab, setTab] = useState<'home' | 'notebooks'>('home');

  const go = useCallback((r: Route) => setStack((s) => [...s, r]), []);
  const replace = useCallback((r: Route) => setStack((s) => [...s.slice(0, -1), r]), []);
  const back = useCallback(() => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)), []);
  const nav: Nav = useMemo(() => ({ go, replace, back }), [go, replace, back]);

  const route = stack[stack.length - 1];
  const key = stack.length + route.name + ('id' in route ? route.id : '');

  let screen;
  switch (route.name) {
    case 'home':
      screen = <Home nav={nav} tab={tab} setTab={setTab} />;
      break;
    case 'editor':
      screen = <Editor id={route.id} nav={nav} />;
      break;
    case 'notebook':
      screen = <NotebookView id={route.id} nav={nav} />;
      break;
    case 'chat':
      screen = <Chat nav={nav} initialMode={route.mode} />;
      break;
    case 'settings':
      screen = <Settings nav={nav} />;
      break;
    case 'draw':
      screen = <Draw nav={nav} />;
      break;
    case 'scan':
      screen = <Scan nav={nav} />;
      break;
    case 'voice':
      screen = <Voice nav={nav} />;
      break;
    case 'search':
      screen = <SearchView nav={nav} />;
      break;
  }

  return (
    <div className="flex h-full items-center justify-center">
      <div className="relative h-full w-full max-w-[430px] overflow-hidden bg-white sm:h-[min(100%,900px)] sm:rounded-[28px] sm:shadow-2xl sm:shadow-[#6B4EFF]/20">
        <div key={key} className="h-full">
          {screen}
        </div>
        <ToastHost />
      </div>
    </div>
  );
}
