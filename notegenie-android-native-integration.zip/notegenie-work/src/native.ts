import { registerPlugin, Capacitor } from '@capacitor/core';
export interface NativeBridge {
  loadSnapshot(): Promise<{ json: string | null }>;
  saveSnapshot(options: { json: string }): Promise<void>;
  loadModel(options: { path: string; context: number; threads: number }): Promise<{ loaded: boolean; model: string }>;
  unloadModel(): Promise<void>;
  generate(options: { prompt: string; maxTokens: number; temperature: number }): Promise<{ text: string }>;
  startListening(): Promise<void>; stopListening(): Promise<{ text: string }>;
  speak(options: { text: string; language: string }): Promise<void>; stopSpeaking(): Promise<void>;
  recognizeImage(options: { path: string }): Promise<{ text: string }>;
  extractPdf(options: { path: string; maxPages: number }): Promise<{ text: string; pages: number }>;
  importModel(): Promise<{ path: string; name: string; size: number }>;
  pickImage(): Promise<{ path: string }>;
  pickDocument(): Promise<{ path: string; mimeType: string; name: string }>;
  addListener(eventName: 'speechPartial' | 'speechFinal' | 'speechError', listenerFunc: (data: any) => void): Promise<{ remove: () => Promise<void> }>;
}
export const Native = registerPlugin<NativeBridge>('NoteGenieNative');
export const isNative = Capacitor.isNativePlatform();
