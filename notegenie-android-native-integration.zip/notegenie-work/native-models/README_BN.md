# Offline model assets (must be supplied separately)

এই source ZIP-এ কোনো বড় মডেল রাখা হয়নি। মডেলগুলো লাইসেন্স ও সাইজের কারণে আলাদাভাবে সংগ্রহ করতে হবে।

## LLM
- 3GB RAM ডিভাইসে প্রথমে 0.5B–1B Q4 GGUF দিয়ে পরীক্ষা করুন; 1.5B Q4-ও সব ডিভাইসে নিরাপদ নয়।
- অ্যাপের Model Import বাটন দিয়ে `.gguf` ফাইল নিন। ফাইল `files/models/`-এ কপি হবে।
- Native llama.cpp source CMake FetchContent-এ নির্দিষ্ট revision থেকে আনা হয়; প্রথম Android build-এ network লাগবে।
- GGUF-এ chat template ও model tokenizer থাকতে হবে।

## Bengali Vosk STT
Vosk Android-compatible Bengali acoustic model সংগ্রহ করে extract করে app-private directory-তে `vosk-model-bn/` নামে রাখতে হবে। Plugin ওই path খোঁজে। এই ZIP-এ Bengali model নেই; model asset ছাড়া offline STT start হবে না।

## Bengali OCR
Tesseract `ben.traineddata` এবং `eng.traineddata` ফাইল `files/tessdata/`-এ কপি করতে হবে। Plugin OCR/PDF scan-এ এই ভাষা দুটো ব্যবহার করে।

## TTS
Android TextToSpeech engine-এর Bengali voice device-এ installed থাকতে হবে। Voice না থাকলে TTS fallback voice নির্ভর করবে device vendor/engine-এর ওপর।
