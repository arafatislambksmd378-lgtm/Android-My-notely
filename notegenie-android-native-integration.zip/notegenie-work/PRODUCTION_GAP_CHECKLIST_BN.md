# NoteGenie AI — Integration & Release Checklist

Legend: `[x]` source implementation present; `[ ]` still requires implementation, assets, build verification, or device QA. Source presence is not proof of production readiness.

## Android platform
- [x] Capacitor Android shell source and MainActivity registration added
- [x] Android manifest, Gradle app configuration, CMake configuration added
- [ ] Gradle sync and Android APK/AAB build verified
- [ ] Signed release build and installation verified

## SQLite
- [x] Native SQLite tables for notebooks, notes, models, chat, metadata
- [x] Transactional snapshot persistence and restore implemented
- [ ] Database schema versioning and migrations
- [ ] Attachment/media files moved to dedicated app-private file store
- [ ] Process-death, low-storage, corruption and backup/restore tests

## llama.cpp / GGUF
- [x] JNI/CMake llama.cpp integration source
- [x] GGUF Storage Access Framework import and app-private copy
- [x] GGUF magic header check and minimum-size check
- [x] Native load/unload/generate bridge
- [x] Single-model-at-a-time load behavior
- [ ] CMake build/API compatibility verified against upstream revision
- [ ] Chat-template aware prompt formatting and true incremental token streaming
- [ ] Model download/resume/checksum/catalog
- [ ] Bengali quality benchmark and prompt regression suite
- [ ] 3GB RAM PSS/RSS, latency, crash and thermal profiling

## Offline Bengali speech
- [x] Vosk Android STT bridge and microphone permission flow
- [x] Android TextToSpeech bridge
- [ ] Bengali Vosk model asset supplied and verified
- [ ] Offline Bengali TTS voice verified on target device
- [ ] Lifecycle, interruption, noise and microphone tests

## OCR / PDF
- [x] Tesseract Android OCR bridge for `ben+eng`
- [x] Android PdfRenderer page rasterization + OCR path
- [ ] `ben.traineddata` and `eng.traineddata` supplied and verified
- [ ] Printed/photo Bengali OCR accuracy test set
- [ ] Large PDF memory and page-limit tests
- [ ] Selectable PDF text extraction (current implementation OCRs rendered pages)

## UI / app integration
- [x] Existing React screens retained in Android WebView shell
- [x] Native SQLite persistence bridge wired into store
- [x] Chat wired to native llama.cpp inference on Android
- [x] Scan flow wired to native image/PDF OCR on Android
- [x] Speech hook wired to Vosk and Android TTS on Android
- [ ] Full OneNote reference pixel/interaction refinement
- [ ] Accessibility, touch-target, font-scale, Android back and rotation QA

## Release security and QA
- [ ] HTML sanitization / rich-text content security review
- [ ] Malformed GGUF/PDF/image and storage exhaustion tests
- [ ] Dependency/license/security audit
- [ ] Automated unit, integration and Android instrumentation tests
- [ ] CI build and signing configuration
- [ ] Target device test: 3GB RAM / 64GB storage

## Required external assets
- `android/app/src/main/assets/vosk-model-bn/` — Bengali Vosk model
- `android/app/src/main/assets/tessdata/ben.traineddata`
- `android/app/src/main/assets/tessdata/eng.traineddata`
- One or more compatible `.gguf` model files imported by user

## Release gate
Do not label production-ready until all relevant unchecked items are complete, APK/AAB builds, native integrations run with real model assets, automated tests pass, and the target 3GB device passes performance/thermal/accuracy QA.
