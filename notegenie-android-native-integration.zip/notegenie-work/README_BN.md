# NoteGenie AI — Android native integration handoff

এই প্যাকেজে দেওয়া OneNote-inspired React UI-কে Android Capacitor shell-এর সঙ্গে যুক্ত করার native source code রয়েছে। SQLite, llama.cpp JNI/CMake, Vosk Bengali speech bridge, Android TextToSpeech, Tesseract OCR এবং PDF page OCR integration source যোগ করা হয়েছে।

**এটি এখনো verified production APK নয়।** এই পরিবেশে Android SDK/NDK/Gradle অনুপস্থিত এবং package/dependency network access পাওয়া যায়নি। তাই Android build, install, native library compile, model inference, Bengali speech/OCR accuracy বা 3GB RAM performance যাচাই করা সম্ভব হয়নি। Required Bengali Vosk/Tesseract model assets ZIP-এ নেই। বিস্তারিত setup ও blockers: `ANDROID_NATIVE_INTEGRATION_BN.md`।

## Build

```bash
npm install
npm run build
npx cap sync android
npx cap open android
```

Android Studio-তে SDK 35, NDK, CMake 3.22.1 এবং JDK 17 configure করে Gradle sync/build করুন। প্রথম native build-এ CMake llama.cpp upstream source fetch করবে।

## Feature status

- UI/UX: supplied React screens retained; Android WebView shell added.
- SQLite: normalized tables + transactional snapshot persistence implemented in native plugin source.
- llama.cpp: JNI/CMake load/generate/unload bridge source added; compile/runtime validation pending.
- GGUF: Android SAF import + app-private copy implemented; model must be supplied by user.
- Bengali STT: Vosk Android bridge added; Bengali model asset required.
- TTS: Android TextToSpeech bridge added; offline Bengali voice is device-dependent.
- OCR: Tesseract Bengali+English image OCR and PDF page rasterization/OCR bridge added; traineddata required.

Do not label as production-ready until Android builds, required assets are installed, tests pass, and the target 3GB device passes memory/thermal/accuracy QA.
