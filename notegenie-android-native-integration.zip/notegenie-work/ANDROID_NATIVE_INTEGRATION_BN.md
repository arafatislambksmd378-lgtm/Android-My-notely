# NoteGenie AI — Android Native Integration

এই সংস্করণে React UI-কে Capacitor Android shell-এর সঙ্গে যুক্ত করার source scaffold যোগ করা হয়েছে। Native plugin source-এ নিচের integration paths আছে:

- **SQLite:** Android SQLite database-এ notebooks, notes, models, chat এবং settings আলাদা table-এ transaction-এর মাধ্যমে snapshot write/read।
- **llama.cpp:** JNI + CMake bridge; Android-এ GGUF import (Storage Access Framework), model load/unload এবং inference API। llama.cpp source CMake build-এ নির্দিষ্ট upstream revision থেকে FetchContent দিয়ে আনা হয়।
- **Bengali speech:** Vosk Android RecognitionListener এবং Android TextToSpeech bridge।
- **OCR:** Tesseract `ben+eng` দিয়ে image OCR; Android `PdfRenderer` দিয়ে PDF page rasterize করে OCR।
- **File picker:** Android SAF দিয়ে GGUF, image ও PDF নির্বাচন।

## Build prerequisites

1. Node.js 20+, npm.
2. Android Studio, Android SDK Platform 35, NDK, CMake 3.22.1, JDK 17.
3. First native build-এ Gradle/CMake dependency এবং llama.cpp source আনতে internet লাগবে। Runtime-এ model inference, SQLite, Vosk, Tesseract offline।

```bash
npm install
npm run build
npx cap sync android
npx cap open android
```

Android Studio-তে Gradle sync করে `app` configuration থেকে build করুন। এই handoff environment-এ Android SDK/Gradle/NDK এবং dependency network ছিল না, তাই APK build বা install test করা যায়নি।

## Required model assets — ZIP-এ ইচ্ছাকৃতভাবে bundled নয়

বড় binary model, traineddata এবং upstream AI weights ZIP-এ রাখা হয়নি। এগুলো ছাড়া সংশ্লিষ্ট offline feature start হবে না।

### Bengali Vosk STT

একটি Vosk Android-compatible Bengali acoustic model নিন। Extract করে নিচের asset path-এ রাখুন, folder-এর ভেতরে Vosk model files থাকতে হবে:

`android/app/src/main/assets/vosk-model-bn/`

Plugin প্রথম launch-এ asset folder app-private storage-এ copy করে। Model asset না থাকলে STT পরিষ্কার error দেবে।

### Bengali Tesseract OCR

`ben.traineddata` এবং `eng.traineddata` রাখুন:

`android/app/src/main/assets/tessdata/`

Plugin এগুলো app-private `files/tessdata/`-এ copy করে। PDF OCR প্রতি page rasterize করে, সর্বোচ্চ ২৫ পৃষ্ঠা process করে। বড় PDF-এর জন্য page limit/bitmap memory আরও tune করতে হবে।

### GGUF LLM

Settings থেকে Import GGUF চাপুন। Android SAF নির্বাচিত ফাইলকে app-private `files/models/`-এ কপি করে। প্রথমবার chat করার সময় llama.cpp model load করে। 3GB RAM-এ 0.5B–1B Q4 model দিয়ে শুরু করুন; 1.5B এবং তার বেশি মডেল ডিভাইসভেদে OOM/thermal throttling ঘটাতে পারে। App একবারে একটি model রাখে।

### Bengali TTS

Android device-এর TextToSpeech engine-এ Bengali voice installed থাকতে হবে। Android API-তে Bengali voice অনুরোধ করা হয়, কিন্তু সব vendor image-এ offline Bengali voice থাকে না। Settings > System > Languages & input > Text-to-speech output-এ voice data install/verify করুন।

## Known implementation limits / release blockers

- Android model import path, JNI bridge ও CMake source যুক্ত; **llama.cpp API/build compatibility এই পরিবেশে compile করে যাচাই করা হয়নি**। First build-এ upstream API mismatch হলে `llama_jni.cpp` adapt করতে হবে।
- Native LLM output বর্তমানে basic Bengali system instruction + prompt ব্যবহার করে; model-specific chat template auto-detection/formatting এবং streaming token callbacks এখনো নেই। `generate()` একবারে পূর্ণ response ফেরত দেয়।
- Native speech listener lifecycle/error recovery এবং বিভিন্ন Android vendor-এর microphone behavior device test প্রয়োজন।
- Vosk Bengali model ও Tesseract traineddata assets সরবরাহ/পরীক্ষা করা হয়নি। তাই model asset না দিলে offline Bengali STT/OCR চালু হবে না।
- Android TTS Bengali offline availability device-dependent।
- Notes snapshot SQLite-এ লেখা হয়, কিন্তু rich-text image data এখনও HTML payload-এর ভেতরে থাকতে পারে; আলাদা attachment file store/migration এখনো প্রয়োজন।
- PDF-এ embedded selectable text সরাসরি extract করা হয় না; বর্তমান path প্রতিটি page render করে OCR চালায়।
- Production signing, backup/restore, DB migrations, automated instrumentation tests, accessibility QA, security audit এবং 3GB RAM device profiling বাকি।
- Browser preview-তে SQLite/llama.cpp/Vosk/Tesseract চলে না; browser-এর LocalStorage ও speech fallback আলাদা preview behavior।

## Safety / privacy

GGUF import শুধু `.gguf` extension এবং minimum size যাচাই করে; পূর্ণ format/tokenizer compatibility llama.cpp load-এ যাচাই হয়। Untrusted GGUF/PDF ব্যবহার করার আগে backup রাখুন। Release build-এ model size limits, checksum, cancellation, storage quota এবং malformed file tests যোগ করতে হবে।
